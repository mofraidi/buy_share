import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-alertes',
  templateUrl: './liste-alertes.component.html',
  styleUrls: ['./liste-alertes.component.css']
})
export class ListeAlertesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
