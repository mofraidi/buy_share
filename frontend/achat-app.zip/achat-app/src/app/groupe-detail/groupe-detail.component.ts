import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {GroupeServiceService} from "../groupe-service.service";
import {HttpParams} from '@angular/common/http';
import {Router} from '@angular/router';

@Component({
  selector: "app-groupe-detail",
  templateUrl: "./groupe-detail.component.html",
  styleUrls: ["./groupe-detail.component.css"],
  changeDetection: ChangeDetectionStrategy.Default
})
export class GroupeDetailComponent implements OnInit {

  private json : any;
 private adhesions : any[];
 private etatGroupe : any;
 private dateDebut : Date;
  private membreUtilisateurDates : any = null;


private penaliteTest : number;
private delaiUtilisationTest : number;
private  delaiTransitionTest : number;
private userSession :any = JSON.parse(sessionStorage.getItem('user'));
private userSessionsDates : any;
private userid : any = this.userSession.id;
private groupeid : any ;
private boutonReserver : boolean = true;
private boutonMettreEnDispo : boolean = true;
private boutonPasserSontour : boolean = true;
private boutonQuitterGroupe : boolean = true;
private boutonconfigGroupe  : boolean = true;
private myDate = new Date();

  constructor(private service: GroupeServiceService, private router:Router) {


  }

  public ngOnInit() {
    //this.service.getGroupe().subscribe((data =>{this.groupe = data;this.membres = this.groupe.adhesions ;} ))

      this.service.getJson(this.service.selectedGroupe.id/*JSON.parse(sessionStorage.getItem('groupeId'))*/).subscribe((data => {
      this.json = data;
      this.adhesions = this.json.adhesions;
      this.getmembreUtilisateurDates();
      console.log("membre utilisateur : "+this.membreUtilisateurDates);
      this.getUserSessionDates();

      this.dateDebut = new Date(this.membreUtilisateurDates.dateDebutUtilisation);

     var userDates = JSON.parse(sessionStorage.getItem('userDates'));
     if(this.json.etat === true && /*this.membreUtilisateurDates*/userDates != null){this.timer1(); }
      //console.log( "date reservation session  = "+this.userSessionsDates.dateReservation + "this.json.etat === true && this.membreUtilisateurDates != null "+(this.json.etat === true && this.membreUtilisateurDates != null));


    }));

  this.timer2();







  }

 public getmembreUtilisateurDates( ){

    var adhesions1 = this.adhesions;

    for(var adh in adhesions1){
        var d = adhesions1[adh].dateDebutUtilisation;
        if (d != null) {
         var utilisateurDates = {userName : adhesions1[adh].userDTO.userName, dateDebutUtilisation:d , nbrHeuresUtilisation : adhesions1[adh].nbrHeuresUtilisation,nbrHeuresPenalisation:adhesions1[adh].nbrHeuresPenalisation  };
          this.membreUtilisateurDates = utilisateurDates /*{userName : adhesions1[adh].userDTO.userName, dateDebutUtilisation:d , nbrHeuresUtilisation : adhesions1[adh].nbrHeuresUtilisation,nbrHeuresPenalisation:adhesions1[adh].nbrHeuresPenalisation  };*/
          sessionStorage.setItem("userDates",JSON.stringify(utilisateurDates));
       break;

       }

      }
 }

 public etatDuGroupe(){

 if (this.json.etat) {this.etatGroupe = "Operationel";}
//else {this.etatGroupe = "En construction";}
 }


  public timer1(){
    setInterval(() => { this.affichageCountDown(); }, 1000);
  }

  public timer2(){
    setInterval(() => { this.affichageCountDown2(); }, 1000);
  }

  affichageCountDown2(){
    this.myDate = new Date();
  }

 public affichageCountDown(){
    var currentDate1 : Date = new Date();
    var userDates = JSON.parse(sessionStorage.getItem('userDates'));
    // @ts-ignore
   var dateDebut = new Date(/*this.membreUtilisateurDates.dateDebutUtilisation*/userDates.dateDebutUtilisation ); //JSON.parse(sessionStorage.getItem('utilisateurDates')).dateDebutUtilisation;

   // @ts-ignore

   var distance = dateDebut  - currentDate1;
    distance = distance + (/*this.membreUtilisateurDates.nbrHeuresUtilisation*60*60*1000*/userDates.nbrHeuresUtilisation*60*60*1000);

   if(distance > 0){

     var jours = Math.floor((distance / (1000 * 60 * 60 * 24)));
     var heures = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
     var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
     var secondes = Math.floor((distance % (1000 * 60)) / 1000);


     document.getElementById("tmprest").innerHTML = jours + "J " + heures + "h "
       + minutes + "m " + secondes + "s " ;
     document.getElementById("tmprest").style.color = "green";

   }

  else {

     var jours = Math.floor(-1*(distance / (1000 * 60 * 60 * 24)));
     var heures = Math.floor(-1*(distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
     var minutes = Math.floor(-1*(distance % (1000 * 60 * 60)) / (1000 * 60));
     var secondes = Math.floor(-1*(distance % (1000 * 60)) / 1000);

     document.getElementById("tmprest").innerHTML = "- ( "+ jours + "J " + heures + "h "
         + minutes + "m " + secondes+ "s)"   ;
     document.getElementById("tmprest").style.color = "red";
   }


 }



  public reserver(iduser : any, idgroupe : any) {

    this.service.reserver(iduser, idgroupe).subscribe((
      data =>
        {
          //location.reload();
          this.ngOnInit();
      }
    ));

  }

  public passerTour(iduser : any, idgroupe : any){

    this.service.passerTour(iduser, idgroupe).subscribe((
      data =>
      { location.reload();
      }
    ));

  }

  public mettreEnDispo(iduser : any , idgroupe : any){

    var currentDate1 : Date = new Date();

    // @ts-ignore
    var tempRestant = this.dateDebut  - currentDate1 + (this.membreUtilisateurDates.nbrHeuresUtilisation*60*60*1000)  ;
    var tempRestantHeures = Math.round(tempRestant/(1000*60*60));
    var penalite : number = 0;
    var delaiUtilisation : number = this.membreUtilisateurDates.nbrHeuresUtilisation;
    var delaiUtilisationMiliSec = delaiUtilisation*3600*1000;
    var delaiUtilisationInitial: number = this.json.article.delaiUtilisation;
    var delaiTransition : number = this.json.article.delaiTransition;

    this.delaiTransitionTest = delaiTransition;




    if(tempRestantHeures < 0){
      if(delaiUtilisation + tempRestantHeures > 0 ){

        delaiUtilisation = delaiUtilisation + tempRestantHeures
      }
      else {
        penalite = -1 * (delaiUtilisation + tempRestantHeures);
        delaiUtilisation = 0;
        }
    }

    else{
      if(delaiUtilisation < delaiUtilisationInitial){
        if(delaiUtilisation + tempRestantHeures > delaiUtilisationInitial){
          delaiUtilisation = delaiUtilisationInitial
        }
        else {
          delaiUtilisation = delaiUtilisation + tempRestantHeures
        }
      }

    }

    this.penaliteTest = penalite;
    this.delaiUtilisationTest = delaiUtilisation;



    this.service.mettreEnDisposition(iduser,idgroupe,penalite,delaiUtilisation,delaiTransition).subscribe((

      data =>
      { //location.reload();
        this.ngOnInit();
      }

    ));
  }

  public getUserSessionDates(){
    console.log("getUserSessionDates()");

    var adhesion1 = this.adhesions;
    if(this.json.etat == true){this.boutonQuitterGroupe = false;}
    for(var adh in adhesion1){
      //var d = adhesions1[adh].dateDebutUtilisation;
      if(adhesion1[adh].userDTO.userName == this.userSession.userName){
        this.userSessionsDates = {dateDebutUtilisation:adhesion1[adh].dateDebutUtilisation, dateReservation:  adhesion1[adh].dateReservation };


      if(this.userSessionsDates.dateDebutUtilisation != null){this.boutonReserver = false;this.boutonPasserSontour = false;}
      else if(this.userSessionsDates.dateReservation != null){ this.boutonMettreEnDispo = false;this.boutonReserver=false;}
        else{{this.boutonMettreEnDispo = false;this.boutonPasserSontour = false;}


      break;
    }
      }



}

  }

  public loadConfig(){
    this.router.navigate(['/config_groupe']);

  }




}///end

