import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'houresToDays'
})
export class HouresToDaysPipe implements PipeTransform {

  transform(value: any) {

    return Math.round(value/24);

  }

}
