import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'virgule'
})
export class VirgulePipe implements PipeTransform {

  transform(value: any) {
    return Math.round(value*100)/100;
  }

}
