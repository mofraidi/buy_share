import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'alerteLink'
})
export class AlerteLinkPipe implements PipeTransform {

  transform(value: any) {

    switch (value) {
      case "demande de validation":
        return "/demandes_validation";
        break;
      case "demande de joindre le groupe validée":
        return "/groupe_detail";
        break;
      case "Annonce Finalisée":
        return "/groupe_detail";
        break;

    }

  }

}
