namespace GroupeModel {
  export interface UserDTO {
    id: number;
    userName: string;
    adhesion: AdhesionDTO[];
  }
}
