namespace GroupeModel {
  export interface GroupeDTO {
    id: number;
    etat: boolean;
    userCreateur: UserDTO;
    adhesions: AdhesionDTO[];
  }
}
