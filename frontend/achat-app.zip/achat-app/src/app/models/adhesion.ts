
namespace GroupeModel {
  export interface AdhesionDTO {
    userDTO: UserDTO;
    groupeDTO: GroupeDTO;
    dateReservation: any;
    dateDebutUtilisation: any;
    nbrHeuresPenalisation: number;
  }
}
