import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GroupeDetailComponent } from './groupe-detail/groupe-detail.component';
import {GroupeServiceService} from './groupe-service.service';
import {HttpClientModule} from '@angular/common/http';
import {ButtonModule} from "primeng/button";
import {MenubarModule} from 'primeng/menubar';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToolbarModule} from 'primeng/toolbar';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MenuAdminComponent } from './menu-admin/menu-admin.component';
import { MenuGestionnaireComponent } from './menu-gestionnaire/menu-gestionnaire.component';
import { MenuUserComponent } from './menu-user/menu-user.component';
import { ListeAnnoncesComponent } from './liste-annonces/liste-annonces.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { LoginComponent } from './login/login.component';
import { DetailAnnonceComponent } from './detail-annonce/detail-annonce.component';
import { DetailUserComponent } from './detail-user/detail-user.component';
import { ListeGroupesComponent } from './liste-groupes/liste-groupes.component';
import { MesArticlesComponent } from './mes-articles/mes-articles.component';
import { ConfigGroupeComponent } from './config-groupe/config-groupe.component';
import { ListeMessagesComponent } from './liste-messages/liste-messages.component';
import { GestionCategoriesComponent } from './gestion-categories/gestion-categories.component';
import { ListeAlertesComponent } from './liste-alertes/liste-alertes.component';
import { ParametrageComponent } from './parametrage/parametrage.component';
import { GestionRolesComponent } from './gestion-roles/gestion-roles.component';
import { JournalComponent } from './journal/journal.component';
import { ChangerRolesComponent } from './changer-roles/changer-roles.component';
import { PublierAnnonceComponent } from './publier-annonce/publier-annonce.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {DataViewModule} from 'primeng/dataview';
import {DialogModule} from 'primeng/dialog';
import { RechercheFormComponent } from './recherche-form/recherche-form.component';
import { ListeAnnoncesFiltresComponent } from './liste-annonces-filtres/liste-annonces-filtres.component';
import { MenuVisiteurComponent } from './menu-visiteur/menu-visiteur.component';
//import { ServiceComponent } from './service/service.component';
import {ServiceMenuService} from './services/service-menu.service';
import {PanelModule} from 'primeng/panel';
import {ToastModule} from 'primeng/toast';
import {MessageModule} from 'primeng/message';
import {DropdownModule, MessageService} from 'primeng/primeng';
import { MesAnnoncesComponent } from './mes-annonces/mes-annonces.component';
import { FileSelectDirective } from 'ng2-file-upload';
import {FileUploadModule} from 'primeng/fileupload';
import { VirgulePipe } from './pipes/virgule.pipe';
import { DemandesValidationComponent } from './demandes-validation/demandes-validation.component';
import { AlertesComponent } from './alertes/alertes.component';
import { AlerteLinkPipe } from './pipes/alerte-link.pipe';
import { BlankComponent } from './blank/blank.component';
import { MessageCollectifComponent } from './message-collectif/message-collectif.component';
import { BloquerUserComponent } from './bloquer-user/bloquer-user.component';
import { HouresToDaysPipe } from './pipes/houres-to-days.pipe';



@NgModule({
  declarations: [
    AppComponent,
    GroupeDetailComponent,
    MenuAdminComponent,
    MenuGestionnaireComponent,
    MenuUserComponent,
    ListeAnnoncesComponent,
    InscriptionComponent,
    LoginComponent,
    DetailAnnonceComponent,
    DetailUserComponent,
    ListeGroupesComponent,
    MesArticlesComponent,
    ConfigGroupeComponent,
    ListeMessagesComponent,
    GestionCategoriesComponent,
    ListeAlertesComponent,
    ParametrageComponent,
    GestionRolesComponent,
    JournalComponent,
    ChangerRolesComponent,
    PublierAnnonceComponent,
    RechercheFormComponent,
    ListeAnnoncesFiltresComponent,
    MenuVisiteurComponent,
    MesAnnoncesComponent,
    //ServiceComponent
    FileSelectDirective,
    VirgulePipe,
    DemandesValidationComponent,
    AlertesComponent,
    AlerteLinkPipe,
    BlankComponent,
    MessageCollectifComponent,
    BloquerUserComponent,
    HouresToDaysPipe,


  ],
  imports: [

    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ButtonModule,
    MenubarModule,
    BrowserAnimationsModule,
    ToolbarModule,
    FormsModule,
    // TableModule,
    DataViewModule,
    DialogModule,
    NgbModule,
    PanelModule,
    ReactiveFormsModule,
    ToastModule,
    MessageModule,
    DropdownModule,
    FileUploadModule

  ],
  providers: [GroupeServiceService, ServiceMenuService,MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
