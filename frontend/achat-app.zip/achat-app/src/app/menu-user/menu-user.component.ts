import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-user',
  templateUrl: './menu-user.component.html',
  styleUrls: ['./menu-user.component.css']
})
export class MenuUserComponent implements OnInit {

  items: any[];
  constructor() { }

  ngOnInit() {

    this.items = [
      {
        label: 'Accueil',routerLink: ['/liste_annonces'], icon: 'pi pi-fw pi-home'

      },
      {
        label: 'Publier annonce',routerLink: ['/publier_annonce'], icon: 'pi pi-fw pi-file',
      },
      {
        label: 'Mes groupes', routerLink: ['/mes_groupes'],icon: 'pi pi-fw pi-share-alt',   //<i class="pi pi-share-alt"></i>
      },
      {
        label: 'Mes articles', routerLink: ['/mes_articles'],icon: 'pi pi-fw pi-mobile',
      },
      {
        label: 'Mes annonces',routerLink: ['/mes_annonces'], icon: 'pi pi-fw pi-list',
      },


    ];

  }

}
