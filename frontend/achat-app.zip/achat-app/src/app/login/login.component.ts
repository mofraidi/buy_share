import { Component, OnInit } from '@angular/core';
import {ServiceMenuService} from '../services/service-menu.service';
import {Router} from '@angular/router';
import {LoginService} from '../services/login.service';
import {InscriptionService} from '../services/inscription.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private login : string;
  private password : string;
  private user : any;


  constructor(private service:ServiceMenuService,private router:Router,private serviceCo :LoginService ,private serviceIns : InscriptionService) { }

  ngOnInit() {
    this.serviceIns.messageConfirmation = "";

  }



  public checkLogin(){
    var login = this.login;
    var pass = this.password;
    this.serviceCo.checkUser(login,pass).subscribe((data => {
      // @ts-ignore
      this.user = data;

      if(this.user == null){
        this.serviceCo.messageConnexion="l'username ou le mot de passe n'est pas correcte, ou le compte n'est pas encore confirmé";
        this.router.navigate(['/login']);
      }
      else{
        var role = this.user.role.nom;


        switch (role) {
          case "user":
             this.serviceCo.interface = "menu_user";
            break;
          case "gestionnaire":
             this.serviceCo.interface = "menu_gestion";
            break;
          case "admin":
             this.serviceCo.interface = "menu_admin";
            break;

        }



        this.router.navigate(["/acceuil"]).then(() =>
        this.router.navigate([".", { outlets: { menus: this.serviceCo.returnInterface(role) } }]));

        sessionStorage.setItem("user",JSON.stringify(this.user)); // JSON.stringify(this.user)



      }

    }));


  }

}
