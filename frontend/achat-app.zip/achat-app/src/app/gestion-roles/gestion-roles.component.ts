import { Component, OnInit } from '@angular/core';
import {RoleService} from '../services/role.service';
import {Message} from 'primeng/api';


@Component({
  selector: 'app-gestion-roles',
  templateUrl: './gestion-roles.component.html',
  styleUrls: ['./gestion-roles.component.css']
})
export class GestionRolesComponent implements OnInit {
  msgRoleExist : string = "";
  msgRoleEnregistre : string = "";
  roleExist : number = 0;
  nomRole : string = "";
  roles : any[];
  nomRoleModif : string = "";
  selectedRole : string;
  btnEnregistrerDisabled: boolean = true;
  msgs: Message[] = [];
  msgsM : Message[] = [];
  msgsS : Message[] = [];


  constructor(private roleService : RoleService) { }

  ngOnInit() {
    this.listeRoles();


  }

  public verifiSiRoleExist(){
    this.msgRoleExist="";
    this.roleService.verifiSiRoleExist(this.nomRole).subscribe((data => {
      // @ts-ignore
      var val = data;

      if(val == 1){this.msgRoleExist = "nom de rôle deja existant!";this.roleExist = 1;}else {this.msgRoleExist = "nom de rôle disponible"; this.btnEnregistrerDisabled=false;}

    }));


  }

  public enregistrerNouvRole(){
    if (this.nomRole == null || this.roleExist == 1){alert("le nom existe deja ou champs vide !");this.roleExist=0;return;}

      this.roleService.enregistrerNouvrole(this.nomRole).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){/*this.msgRoleEnregistre = "le nouveau rôle "+this.nomRole+" a eté enregistré";*/this.showSuccessEnr()}
        this.ngOnInit();

    }));
  }

  public listeRoles(){
    this.roleService.getListRoles().subscribe((data => {
      // @ts-ignore
      this.roles = data;

    }));
  }

  public modifierRole(){
   if(this.selectedRole == null || this.nomRoleModif == ""){alert("champs non valide") ; return;}
    this.roleService.modifierRole(this.selectedRole, this.nomRoleModif).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){/*alert("le rôle "+this.selectedRole+" a ete mofifié en "+this.nomRoleModif);*/this.showSuccessEnrMod(); this.nomRoleModif == "";this.ngOnInit();}
      else{alert("une erreur est survenue!")}

    }));
  }

  public suppRole(){
    if(this.selectedRole == null){alert("aucun rôle selectionné");}
    this.roleService.supprimerRole(this.selectedRole).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){/*alert("le rôle "+this.selectedRole+" a été supprimé.");*/this.showSuccessEnrSup(); this.ngOnInit();}

    }));
  }

  showSuccessEnr() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'le rôle a été enregistré'});
  }

  showSuccessEnrMod() {
    this.msgsM = [];
    this.msgsM.push({severity:'success', summary:'Success Message', detail:'le rôle a été modifié'});
  }

  showSuccessEnrSup() {
    this.msgsS = [];
    this.msgsS.push({severity:'success', summary:'Success Message', detail:'le rôle a été supprimé'});
  }
}
