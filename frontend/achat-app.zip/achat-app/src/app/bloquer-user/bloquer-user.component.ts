import { Component, OnInit } from '@angular/core';
import {InscriptionService} from '../services/inscription.service';

@Component({
  selector: 'app-bloquer-user',
  templateUrl: './bloquer-user.component.html',
  styleUrls: ['./bloquer-user.component.css']
})
export class BloquerUserComponent implements OnInit {
  private userName : string;
  private nbrHeuresBlocage : number;
  private user : any;
  private userNameExistMsg : string = "";
  private btnBloquerEnbl : boolean = true;
  private btnDebloquerEnbl : boolean = true;
  constructor(private serviceIns : InscriptionService) { }

  ngOnInit() {
  }
  public userNameExists(){

    var val : any;
    this.serviceIns.userNameExistsObj(this.userName).subscribe((data => {

      this.user = data;
      if(this.user == null){this.userNameExistMsg ="l'user n'existe pas!";this.btnBloquerEnbl = true;}

      if(this.user.blocage.bloque == true  ){
        this.userNameExistMsg = "user est blogué depuis : "+this.user.blocage.dateHeureDebut+" pour une periode de : "+this.user.blocage.duree+" h";
        this.btnDebloquerEnbl = false;
      }
      if(this.user.blocage.bloque == false){
        this.userNameExistMsg ="l'user n'est pas bloqué";
        this.btnBloquerEnbl = false;
      }
    }));
  }

  public mouseEnter(){
    this.userNameExistMsg = "";
  }

}
