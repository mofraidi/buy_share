import { Component, OnInit } from '@angular/core';
import {JournalService} from '../services/journal.service';

@Component({
  selector: 'app-journal',
  templateUrl: './journal.component.html',
  styleUrls: ['./journal.component.css']
})
export class JournalComponent implements OnInit {

  private journal : any[];

  constructor(private serviceJournal : JournalService ) { }

  ngOnInit() {
    this.getJournal();
  }

  public getJournal(){
    this.serviceJournal.getJournal().subscribe((data => {
      // @ts-ignore
      this.journal = data;

    }));

  }

}
