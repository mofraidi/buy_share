import { Component, OnInit } from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {FileService} from '../services/file.service';

@Component({
  selector: 'app-detail-annonce',
  templateUrl: './detail-annonce.component.html',
  styleUrls: ['./detail-annonce.component.css']
})
export class DetailAnnonceComponent implements OnInit {

  private categories : any[];
  private titre : string;
  private desciption : string;
  private nbrMin : string;
  private nbrMax : string;
  private nomArticle : string;
  private  prix : string;
  private categ : string = "";
  private delaiUtilisation : string;
  private delaiMinUtilisation : string;
  private delaiTransition : string;
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  private pictures : any[];

  constructor(private serviceAnnonce : AnnonceServiceService, private fileService : FileService) { }

  ngOnInit() {
    this.serviceAnnonce.getCategoriesJson().subscribe((data => {
      // @ts-ignore
      this.categories = data;

    }));
    this.nbrMin = this.serviceAnnonce.selectedAnnonce.nbrMinMemmbres;
    this.titre = this.serviceAnnonce.selectedAnnonce.titre;
    this.desciption = this.serviceAnnonce.selectedAnnonce.description;

    this.nbrMax = this.serviceAnnonce.selectedAnnonce.nbrMaxMembres;
    this.nomArticle = this.serviceAnnonce.selectedAnnonce.articleDTO.nom;
    this.prix = this.serviceAnnonce.selectedAnnonce.articleDTO.prix;
    this.delaiUtilisation = this.serviceAnnonce.selectedAnnonce.articleDTO.delaiUtilisation;
    this.delaiMinUtilisation = this.serviceAnnonce.selectedAnnonce.articleDTO.delaiMinUtilisation;
    this.delaiTransition = this.serviceAnnonce.selectedAnnonce.articleDTO.delaiTransition;
    this.pictures = this.serviceAnnonce.selectedAnnonce.articleDTO.ressourcesDTO;
  }

  public onDrop()
  {

    var fd = new FormData();
    var ins = (<HTMLInputElement>  document.getElementById('classicFile')).files.length ;
    for (var x = 0; x < ins; x++) {
      fd.append("files[]", (<HTMLInputElement>document.getElementById('classicFile')).files[x]);
      //console.log(ins[x].name);
    }

    var selectCat = document.getElementById("categ" ) as HTMLSelectElement;
    this.categ = selectCat.options[selectCat.selectedIndex].text;
    fd.append("idAnnonce",this.serviceAnnonce.selectedAnnonce.id);
    fd.append("idArticle",this.serviceAnnonce.selectedAnnonce.articleDTO.id);
    fd.append("titre",this.titre);
    fd.append("description",this.desciption);
    fd.append("nbrMin",this.nbrMin);
    fd.append("nbrMax",this.nbrMax);
    fd.append("nomArticle",this.nomArticle);
    fd.append("prix",this.prix);
    fd.append("categorie",this.categ);
    fd.append("delaiUtilisation",this.delaiUtilisation);
    fd.append("delaiMinUtilisation",this.delaiMinUtilisation);
    fd.append("delaiTransition",this.delaiTransition);
    fd.append("userName",this.userSession.userName);

    this.fileService.uploadFileModif(fd).subscribe((data => {
      var val = data;
      /*if(val == 1)*/
      {alert("l'annonce a été modifié avec succès!");}

    }));




  }

}
