import { Component, OnInit } from '@angular/core';
import {DetailUserService} from '../services/detail-user.service';

@Component({
  selector: 'app-detail-user',
  templateUrl: './detail-user.component.html',
  styleUrls: ['./detail-user.component.css']
})
export class DetailUserComponent implements OnInit {
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  private selectedUser : any;
  private role : any;


  constructor(private detailUserService : DetailUserService) { }

  ngOnInit() {
    if(this.userSession != null){
      this.role = this.userSession.role.nom

    }
  }

}
