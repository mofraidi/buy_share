import { Component, OnInit } from '@angular/core';
import {AlertesService} from '../services/alertes.service';

@Component({
  selector: 'app-alertes',
  templateUrl: './alertes.component.html',
  styleUrls: ['./alertes.component.css']
})
export class AlertesComponent implements OnInit {

  constructor(private alertService : AlertesService) { }

  ngOnInit() {



  }

}
