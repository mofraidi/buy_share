import { Component, OnInit } from '@angular/core';
import {DemandesValidationService} from '../services/demandes-validation.service';

@Component({
  selector: 'app-demandes-validation',
  templateUrl: './demandes-validation.component.html',
  styleUrls: ['./demandes-validation.component.css']
})
export class DemandesValidationComponent implements OnInit {

  private mesDemandes : any[];
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));

  constructor(private demandesService : DemandesValidationService) {



  }

  ngOnInit() {
    this.demandesService.getMesDemandes(this.userSession.userName).subscribe((data => {
      // @ts-ignore
      this.mesDemandes = data;

    }));
  }

  valider(idUser : any, idGroupe : any){
   this.demandesService.validerDemande(idUser,idGroupe).subscribe((data => {
     var val = data;
     if(val == 1){alert("la demande a été validée");}

     this.ngOnInit();

   }));
  }


  rejeter(idUser : any, idGroupe : any){
    this.demandesService.rejeterDemande(idUser,idGroupe).subscribe((data => {

      var val = data;
      if(val == 1){alert("la demande a été rejetée");}


      this.ngOnInit();

    }));
  }

}
