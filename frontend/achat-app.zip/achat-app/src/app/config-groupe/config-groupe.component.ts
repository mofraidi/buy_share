import { Component, OnInit } from '@angular/core';
import {GroupeServiceService} from '../groupe-service.service';
import {Message} from 'primeng/api';

@Component({
  selector: 'app-config-groupe',
  templateUrl: './config-groupe.component.html',
  styleUrls: ['./config-groupe.component.css']
})
export class ConfigGroupeComponent implements OnInit {

  private delaiUtil : number;
  private delaiMinUtil : number;
  private delaiTransition : number;
  msgs: Message[] = [];



  constructor(private serviceGroupe : GroupeServiceService) { }

  ngOnInit() {
    this.delaiUtil = this.serviceGroupe.selectedGroupe.article.delaiUtilisation;
    this.delaiMinUtil = this.serviceGroupe.selectedGroupe.article.delaiMinUtilisation;
    this.delaiTransition = this.serviceGroupe.selectedGroupe.article.delaiTransition;

  }



  public ModifierConfiguration(){
    this.serviceGroupe.configGroupe(this.serviceGroupe.selectedGroupe.id,this.delaiUtil,this.delaiMinUtil,this.delaiTransition).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1) {this.showSuccess()}

    }));

  }

  showSuccess() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'la configuration a été modifiée avec succès !'});
  }

}
