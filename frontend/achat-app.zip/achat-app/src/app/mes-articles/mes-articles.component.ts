import { Component, OnInit } from '@angular/core';
import {GroupeServiceService} from '../groupe-service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-mes-articles',
  templateUrl: './mes-articles.component.html',
  styleUrls: ['./mes-articles.component.css']
})
export class MesArticlesComponent implements OnInit {

  private mesGroupes : any[];
  private selecteIdGroupe : any;
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));

  constructor(private service: GroupeServiceService, private router:Router) {
    this.service.getMesGroupes(JSON.parse(sessionStorage.getItem('user')).id)

      .subscribe((data => {
        // @ts-ignore
        this.mesGroupes = data;

      }));

  }

  ngOnInit() {
  }

  selectGroupe(groupe : any) {

    this.service.selectedGroupe = groupe;
    this.router.navigate(['/groupe_detail']);

  }

}
