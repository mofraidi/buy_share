import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {MessageService, SelectItem} from 'primeng/api';
import {InscriptionService} from '../services/inscription.service';
import {Router} from '@angular/router';



@Component({
  selector: 'app-inscription',
  templateUrl: './inscription.component.html',
  styleUrls: ['./inscription.component.css'],
  providers: [MessageService]
})
export class InscriptionComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  private userName : string;
  private passWord : string ="";
  private passWord2 : string;
  private localites : any[];
  private localite : string;
  private eMail : string;
  private inscription : any ;
  private messageConfirmation : string = "";
  private userNameExist : string = "";
  private emailExist : string = "";
  private msgPassPasEgaux : string = "";




  constructor(private formBuilder: FormBuilder, private service : InscriptionService,private router:Router ) { }

  ngOnInit() {

    this.registerForm = this.formBuilder.group({
    username: ['', [Validators.required,Validators.minLength(4), Validators.maxLength(20)] ],

    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4),Validators.maxLength(20)]]

  });

    this.service.getLocalitesJson().subscribe((data => {
      // @ts-ignore
      this.localites = data;

    }));


  }



  get f() { return this.registerForm.controls; }

  public userNameExists(){
    //this.userNameExist = "";
    var val : number;
    this.service.userNameExists(this.userName).subscribe((data => {
      // @ts-ignore
      val = data;

      if(val == 1){this.userNameExist = "usename deja existant";}

    }));
  }

  public eMailExists(){
    this.emailExist = "";
    var val : number;
    this.service.eMailExists(this.eMail).subscribe((data => {
      // @ts-ignore
      val = data;

      if(val == 1){this.emailExist = "email deja existant";}

    }));
  }

  verifiSiPassEgaux(e){
    if(e.target.value != this.passWord){
      this.msgPassPasEgaux = "les deux mots de passe ne sont pas egaux !";
    }
  }

  msgClear(){
    this.msgPassPasEgaux = "";
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid

    if (this.registerForm.invalid) {
      return;
    }

    var selectLoc = document.getElementById("localitesSelect" ) as HTMLSelectElement;
    console.log("valeur de select est : "+selectLoc.options[selectLoc.selectedIndex].text+"username : "+this.userName+"pass : "+this.passWord+"email : "+this.eMail);
    this.localite = selectLoc.options[selectLoc.selectedIndex].text
    this.service.postUser(this.userName,this.passWord,this.eMail,this.localite).subscribe((data => {
      this.inscription = data;
      this.service.messageConfirmation = (this.inscription == 1)?"veuillez cliquer sur le lien envoyé à votre email pour confirmer l'inscription puis introduire l'username et le mot de passe  ":"erreur innatendue";

    }));
    this.router.navigate(['/login']);


  }




}
