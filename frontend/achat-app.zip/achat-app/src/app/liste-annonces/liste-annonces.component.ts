import { Component, OnInit } from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {DetailUserService} from '../services/detail-user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-liste-annonces',
  templateUrl: './liste-annonces.component.html',
  styleUrls: ['./liste-annonces.component.css']
})
export class ListeAnnoncesComponent implements OnInit {
  private listeAnnonces : any[];

  private selectedCar: any;
  private listeUserNames : any[];
  private displayDialog: boolean;
  private photoPrincipaleArticle : string = "";
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  private btnJoindre : any = false;

  constructor(private service : AnnonceServiceService, private detailUserService : DetailUserService,private router:Router ) { }

  ngOnInit() {


    this.service.getAnnoncesJson().subscribe((data => {
      // @ts-ignore
      this.listeAnnonces = data;

    }));


  }

  selectCar(event: Event, car: any) {
    this.selectedCar = car;
    this.displayDialog = true;

    this.service.getListeUserNamesAnnonce(this.selectedCar.articleDTO.id).subscribe((data => {
      // @ts-ignore
      this.listeUserNames = data;
    }));

    event.preventDefault();

  }

  onDialogHide() {
    this.selectedCar = null;
  }

  public joindreGroupe(id_user : any, id_article : any){
this.service.joindreGroupe(id_user,id_article).subscribe((data => {
  // @ts-ignore
  var x = data;

  if(x == 1){this.btnJoindre=true;
  alert("la demande pour joindre le groupe a été faite avec success !")}
}));
  }


  public detailUser(selectedUser : any ){
    this.detailUserService.selectedUser = selectedUser;

        this.router.navigate(["/user_detail"])
  }

}
