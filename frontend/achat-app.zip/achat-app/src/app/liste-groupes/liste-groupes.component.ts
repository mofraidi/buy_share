import {Component, Input, OnInit} from '@angular/core';
import {GroupeServiceService} from '../groupe-service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-liste-groupes',
  templateUrl: './liste-groupes.component.html',
  styleUrls: ['./liste-groupes.component.css']
})
export class ListeGroupesComponent implements OnInit {
   private mesGroupes : any[];
   private selecteIdGroupe : any;
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  constructor(private service: GroupeServiceService,private router:Router  ) { }

  ngOnInit() {

    this.service.getMesGroupes(JSON.parse(sessionStorage.getItem('user')).id)

    .subscribe((data => {
      // @ts-ignore
      this.mesGroupes = data;

    }));


  }

  selectGroupe(groupe : any) {

    this.service.selectedGroupe = groupe;
    this.router.navigate(['/groupe_detail']);

  }

  public loadConfig(){
    this.router.navigate(['/config_groupe']);

  }

}
