import { Component, OnInit } from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-mes-annonces',
  templateUrl: './mes-annonces.component.html',
  styleUrls: ['./mes-annonces.component.css']
})
export class MesAnnoncesComponent implements OnInit {
  private mesAnnonces : any[];
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  constructor(private serviceAnnonce : AnnonceServiceService,private router:Router) { }

  ngOnInit() {
    this.serviceAnnonce.getMesAnnonces(this.userSession.id).subscribe((data => {
      // @ts-ignore
      this.mesAnnonces = data;
    }));
  }

  public detailAnnonce(annonce : any){
    this.serviceAnnonce.selectedAnnonce = annonce;
    this.router.navigate(['/annonce_detail']); //annonce_detail


  }

  finaliserAnnonce(id: any) {

    this.serviceAnnonce.finaliserAnnonce(id).subscribe((data) => {
        alert("l'annonce a été finalisée");
        this.ngOnInit();
      },
      (err) => {console.log(err);alert("erreur innatendue!");});


  }
}
