import { Component, OnInit } from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {CategorieService} from '../services/categorie.service';

@Component({
  selector: 'app-menu-visiteur',
  templateUrl: './menu-visiteur.component.html',
  styleUrls: ['./menu-visiteur.component.css']
})
export class MenuVisiteurComponent implements OnInit {

  private motCle : any = "";
  private cat : any = "" ;
  private codePostal : any = "";
  private distance : any = 5;
  private categories : any[];

  constructor(private service : AnnonceServiceService, private serviceCat : CategorieService) { }

  ngOnInit() {

    this.serviceCat.getListCategories().subscribe((data) => {

        // @ts-ignore
        this.categories = data;
      },
      (err) => {console.log(err)});


  }

  public afficherValeurs(){

    //console.log(this.codePostal);
    var selectCat = document.getElementById("cat" ) as HTMLSelectElement;
    var selectDist = document.getElementById("distance" )as HTMLSelectElement;


  }

  public postRecherche(){
    var selectCat = document.getElementById("cat" ) as HTMLSelectElement;

    var dist = 0;


    switch (this.distance) {
      case "5km":
        dist = 5;
        break;
      case "10km":
        dist = 10;
        break;
      case "20":
        dist = 20;
        break;
      case "25":
        dist = 25;
        break;
      case "50":
        dist = 50;
        break;
      case "100":
        dist = 100;
        break;

    }

    this.service.mot_cle = this.motCle;
    if(this.cat == "Toute categories"){this.cat = "";}
    this.service.code_postal = this.codePostal;
    this.service.dist = dist;
    this.service.categ = this.cat;
    //alert("dist = "+ dist+"categ = "+this.cat+"codeP = "+this.codePostal+"motcle = "+this.motCle);

  }

} // eof
