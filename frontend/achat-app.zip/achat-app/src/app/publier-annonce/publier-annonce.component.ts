import { Component, OnInit } from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Observable} from "rxjs";
import {FileUploader} from 'ng2-file-upload';
import {FileService} from '../services/file.service';
import {HttpResponse} from '@angular/common/http';
import {$} from 'protractor';


const UploadURL = 'http://localhost:8080/annonces/files';

@Component({
  selector: 'app-publier-annonce',
  templateUrl: './publier-annonce.component.html',
  styleUrls: ['./publier-annonce.component.css']
})
export class PublierAnnonceComponent implements OnInit {
  private categories : any[];
  private titre : string;
  private desciption : string;
  private nbrMin : string;
  private nbrMax : string;
  private nomArticle : string;
  private  prix : string;
  private categ : string = "";
  private delaiUtilisation : string;
  private delaiMinUtilisation : string;
  private delaiTransition : string;

  selectedFiles: FileList;
  currentFile: File;
  private formData = new FormData();
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));

  public uploader: FileUploader = new FileUploader({url: UploadURL, itemAlias: 'photo'});



  constructor(private service : AnnonceServiceService, private fb: FormBuilder,private fileService : FileService) { }

  ngOnInit() {

    this.service.getCategoriesJson().subscribe((data => {
      // @ts-ignore
      this.categories = data;

    }));

    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('FileUpload:uploaded:', item, status, response);
      alert('File uploaded successfully');
    };

  }

  public afficheFiles(event){
    console.log("leng ="+event.target.files[0].name);// [0].name
  }


  selectFile(event) {
    this.selectedFiles = event.target.files;
    console.log("leng"+this.selectedFiles);
  }


  public onDrop()
  {

    var fd = new FormData();
    var ins = (<HTMLInputElement>  document.getElementById('classicFile')).files.length ;
    for (var x = 0; x < ins; x++) {
      fd.append("files[]", (<HTMLInputElement>document.getElementById('classicFile')).files[x]);
      //console.log(ins[x].name);
    }

    var selectCat = document.getElementById("categ" ) as HTMLSelectElement;
    this.categ = selectCat.options[selectCat.selectedIndex].text;

    fd.append("titre",this.titre);
    fd.append("description",this.desciption);
    fd.append("nbrMin",this.nbrMin);
    fd.append("nbrMax",this.nbrMax);
    fd.append("nomArticle",this.nomArticle);
    fd.append("prix",this.prix);
    fd.append("categorie",this.categ);
    fd.append("delaiUtilisation",this.delaiUtilisation);
    fd.append("delaiMinUtilisation",this.delaiMinUtilisation);
    fd.append("delaiTransition",this.delaiTransition);
    fd.append("userName",this.userSession.userName);

    this.fileService.uploadFile( fd).subscribe(data => {
       var val = data;
        // @ts-ignore
      if(val == 1){
          alert("l'annonce a été publiée avec succès!");
        }

    })



  }





}// eof
