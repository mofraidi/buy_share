import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {GroupeDetailComponent} from './groupe-detail/groupe-detail.component';
import {PublierAnnonceComponent} from './publier-annonce/publier-annonce.component';
import {ParametrageComponent} from './parametrage/parametrage.component';
import {MesArticlesComponent} from './mes-articles/mes-articles.component';
import {LoginComponent} from './login/login.component';
import {ListeMessagesComponent} from './liste-messages/liste-messages.component';
import {ListeGroupesComponent} from './liste-groupes/liste-groupes.component';
import {ListeAnnoncesComponent} from './liste-annonces/liste-annonces.component';
import {ListeAlertesComponent} from './liste-alertes/liste-alertes.component';
import {JournalComponent} from './journal/journal.component';
import {InscriptionComponent} from './inscription/inscription.component';
import {GestionRolesComponent} from './gestion-roles/gestion-roles.component';
import {GestionCategoriesComponent} from './gestion-categories/gestion-categories.component';
import {DetailUserComponent} from './detail-user/detail-user.component';
import {DetailAnnonceComponent} from './detail-annonce/detail-annonce.component';
import {ConfigGroupeComponent} from './config-groupe/config-groupe.component';
import {ChangerRolesComponent} from './changer-roles/changer-roles.component';
import {ListeAnnoncesFiltresComponent} from './liste-annonces-filtres/liste-annonces-filtres.component';
import {MenuVisiteurComponent} from './menu-visiteur/menu-visiteur.component';
import {AppComponent} from './app.component';
import {RechercheFormComponent} from './recherche-form/recherche-form.component';
import {MenuUserComponent} from './menu-user/menu-user.component';
import {MenuGestionnaireComponent} from './menu-gestionnaire/menu-gestionnaire.component';
import {MenuAdminComponent} from './menu-admin/menu-admin.component';
import {AlertesComponent} from './alertes/alertes.component';
import {DemandesValidationComponent} from './demandes-validation/demandes-validation.component';
import {BlankComponent} from './blank/blank.component';
import {MessageCollectifComponent} from './message-collectif/message-collectif.component';
import {BloquerUserComponent} from './bloquer-user/bloquer-user.component';
import {MesAnnoncesComponent} from './mes-annonces/mes-annonces.component';

const routes: Routes = [
 { path: '', redirectTo: '/acceuil', pathMatch: 'full' },

  //{ path: 'acceuil', component: ListeGroupesComponent, children: [{ path: '', component: MenuVisiteurComponent,outlet: 'menus'}]},


  { path: 'acceuil', component: ListeAnnoncesComponent },
  /*{ path: '**', redirectTo: '/liste_annonces', pathMatch: 'full'},*/
  { path: 'groupe_detail', component: GroupeDetailComponent },
  { path: 'publier_annonce', component: PublierAnnonceComponent },
  { path: 'mes_groupes', component: ListeGroupesComponent },
  { path: 'mes_articles', component: MesArticlesComponent },
  { path: 'mes_annonces', component: MesAnnoncesComponent },
  { path: 'config_groupe', component: ConfigGroupeComponent },
  { path: 'gestion_categories', component: GestionCategoriesComponent },
  { path: 'gestion_roles', component: GestionRolesComponent },
  { path: 'parametrage', component: ParametrageComponent },

  { path: 'changer_roles', component: ChangerRolesComponent },
  { path: 'login', component: LoginComponent },
  { path: 'inscription', component: InscriptionComponent },
  { path: 'liste_messages', component: ListeMessagesComponent },


  { path: 'liste_annonces', component: ListeAnnoncesComponent },
  { path: 'liste_alertes', component: ListeAlertesComponent },
  { path: 'user_detail', component: DetailUserComponent },
  { path: 'annonce_detail', component: DetailAnnonceComponent },
  { path: 'liste_ann_f', component: ListeAnnoncesFiltresComponent },
  { path: 'menu_visiteur', component: MenuVisiteurComponent },
  { path: 'app', component: AppComponent },
  { path: 'rech_ann_user', component: RechercheFormComponent },
  { path: 'menu_user', component: MenuUserComponent,outlet: 'menus' },
  { path: 'menu_gestion', component: MenuGestionnaireComponent,outlet: 'menus' },
  { path: 'menu_admin', component: MenuAdminComponent,outlet: 'menus' },
  { path: 'alertes', component: AlertesComponent },
  { path: 'msg_coll', component: MessageCollectifComponent },
  { path: 'demandes_validation', component: DemandesValidationComponent },
  { path: 'blank', component: BlankComponent,outlet: 'menus' },
  { path: 'bloquer_user', component: BloquerUserComponent },
  { path: 'journal', component: JournalComponent }
  //bloquer_user BloquerUserComponent




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
