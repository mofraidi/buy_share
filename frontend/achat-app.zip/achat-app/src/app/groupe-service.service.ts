import { Injectable } from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Router} from '@angular/router';

@Injectable({
  providedIn: "root"
})
export class GroupeServiceService {

  selectedIdGroupe: any;
  selectedGroupe : any;
  confirmationMsg : any = "";

  constructor(private http: HttpClient,private router:Router) { }

  public getGroupe(){

    return this.http.get<GroupeModel.GroupeDTO>("http://localhost:8080/groupe/membres");

  }

  public getJson (id_groupe){
   let data = {idGroupe : id_groupe };
    return this.http.get("http://localhost:8080/groupe/membres",{params:data});
  }

  public reserver(iduser : any, idgroupe : any){
    let data = {idUser: iduser, idGroupe : idgroupe};
    return this.http.get("http://localhost:8080/groupe/reserver",{params : data});
  }

  public passerTour(iduser : any, idgroupe : any){
    let data = {idUser: iduser, idGroupe : idgroupe};
    return this.http.get("http://localhost:8080/groupe/passer_tour",{params : data});
  }

  public mettreEnDisposition(iduser : any, idgroupe : any, penalite_ : any,delai_utilisation : any, delai_transition : any ){
    let data = {idUser: iduser, idGroupe : idgroupe, penalite : penalite_, delaiUtilisation : delai_utilisation, delaiTransition: delai_transition };
    return this.http.get("http://localhost:8080/groupe/mettre_dispo",{params : data});
  }

  public getMesGroupes (id_user){
    let data = {idUser : id_user}
    return this.http.get("http://localhost:8080/groupe/mes_groupes",{params:data});
  }

  public getMyMembersGroupeUserNames(id_user, id_groupe){
    let data = {idUser : id_user, idGroupe : id_groupe};
    return this.http.get("http://localhost:8080/groupe/user_names",{params:data});

  }

  public envoyerMsgcollectif(message : any, user_names: any[], id_groupe : any, id_user_src){
      let data = {msg:message, userNames : user_names, idGroupe : id_groupe, idUserSource : id_user_src};
    return this.http.get("http://localhost:8080/message/msg_coll",{params:data});
  }

  public configGroupe(id_groupe: any, id_delai_utilisation : any, delai_min_utilisation : any, delai_transition : any ){
    let data = {idGroupe:id_groupe,delaiUtilisation:id_delai_utilisation,delaiMinUtilisation:delai_min_utilisation,delaiTransition:delai_transition};
    return this.http.get("http://localhost:8080/groupe/config_groupe",{params:data});

  }







}
