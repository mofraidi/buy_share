import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private http : HttpClient) { }

  public verifiSiRoleExist(nom_role : any){
    let data = {nomRole : nom_role}
    return this.http.get("http://localhost:8080/rolesrest/role_exist",{params : data} );
  }

  public enregistrerNouvrole(nom_role : any){

    let data = {nomRole : nom_role}
    return this.http.get("http://localhost:8080/rolesrest/enregist_role",{params : data} );

  }

  public getListRoles(){

    return this.http.get("http://localhost:8080/rolesrest/liste" );
  }

  public modifierRole(nom_role : string, nouv_nom_role : string){
    let data = {nomRole : nom_role, nouvNomRole : nouv_nom_role}
    return this.http.get("http://localhost:8080/rolesrest/modifier_role", {params:data} );
  }

  public supprimerRole(nom_role : string){
    let data = {nomRole : nom_role}
    return this.http.get("http://localhost:8080/rolesrest/supp_role", {params:data} );
  }


  public changerRoleUser(user_name : string, nom_role : string){
    let data = {userName : user_name, nomRole : nom_role}
    return this.http.get("http://localhost:8080/usersrest/maj_role",{params : data} );
  }

}// eof
