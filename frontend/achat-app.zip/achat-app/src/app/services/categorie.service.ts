import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategorieService {

  constructor(private http : HttpClient) { }

  public verifiSiCategorieeExist(nom_cat : any){
    let data = {nomCat : nom_cat}
    return this.http.get("http://localhost:8080/categories/cat_exist",{params : data} );
  }

  public enregistrerNouvCat(nom_cat : any){

    let data = {nomCat : nom_cat}
    return this.http.get("http://localhost:8080/categories/enregist_cat",{params : data} );

  }

  public getListCategories(){

    return this.http.get("http://localhost:8080/categories/liste" );
  }

  public modifierCategorie(nom_cat : string, nouv_nom_cat : string){
    let data = {nomCat : nom_cat, nouvNomCat : nouv_nom_cat}
    return this.http.get("http://localhost:8080/categories/modifier_cat", {params:data} );
  }

  public supprimerCategorie(nom_cat : string){
    let data = {nomCat : nom_cat}
    return this.http.get("http://localhost:8080/categories/supp_cat", {params:data} );
  }

}// eof
