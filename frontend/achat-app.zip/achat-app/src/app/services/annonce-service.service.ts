import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AnnonceServiceService {


  public mot_cle: any;
  public categ : any;
  public code_postal : any;
  public dist : any;
  public selectedAnnonce : any;

  constructor(private http: HttpClient) { }

  public getAnnoncesJson(){
    return this.http.get("http://localhost:8080/annonces/liste_annonces");
  }

  public getAnnoncesFiltreesJson(mot_cle : any, categ : any, code_postal : any, dist : any){
    let data = {motCle: mot_cle, cat : categ,codePostal : code_postal, distance : dist};
    return this.http.get("http://localhost:8080/annonces/liste_annonces_filtres",{params : data});
  }

  public getCategoriesJson(){
    return this.http.get("http://localhost:8080/annonces/liste_categories");
  }

  public getListeUserNamesAnnonce(id_article:any){
    let data = {idArticle:id_article};
    return this.http.get("http://localhost:8080/annonces/liste_membres_annonce",{params:data});//
  }

  public joindreGroupe(id_user:any, id_article: any){
    let data = {idUser : id_user,idArticle:id_article};
    return this.http.get("http://localhost:8080/groupe/joindre_groupe",{params:data});//
  }

  public getMesAnnonces(id_user : any){
    let data = {idUser : id_user};
    return this.http.get("http://localhost:8080/annonces/mes_annonces",{params:data});
  }

  public finaliserAnnonce(id_annonce : any){
    let data = {idAnnonce : id_annonce};
    return this.http.get("http://localhost:8080/annonces/finaliser",{params:data});
  }





}
