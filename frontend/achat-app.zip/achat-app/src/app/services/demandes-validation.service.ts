import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DemandesValidationService {

  constructor(private http:HttpClient) { }

  public getMesDemandes(username : any){
    var data = {userName : username};
    return this.http.get("http://localhost:8080/usersrest/demandes",{params:data});//
  }

  public validerDemande(id_user : any, id_groupe){
    var data = {idUser : id_user, idGroupe : id_groupe};
    return this.http.get("http://localhost:8080/groupe/valider",{params:data});//
  }

  public rejeterDemande(id_user : any, id_groupe){
    var data = {idUser : id_user, idGroupe : id_groupe};
    return this.http.get("http://localhost:8080/groupe/rejeter",{params:data});//
  }

}
