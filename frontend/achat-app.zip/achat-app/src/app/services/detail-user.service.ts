import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DetailUserService {

  selectedUser : any;

  constructor() { }
}
