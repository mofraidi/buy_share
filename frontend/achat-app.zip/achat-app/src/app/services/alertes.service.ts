import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AlertesService {
  mesAlertes: any[];
  lu : boolean;
  btnAlerteEtat : boolean = false;// alertes vues/non vues

  constructor(private http: HttpClient) { }

  public getMesAlertes(username : any){
    var data = {userName : username};
    return this.http.get("http://localhost:8080/usersrest/mes_alertes",{params:data});// http://localhost:8080/usersrest/demandes
  }

  public alerteLues(username : any){
    var data = {userName : username};
    return this.http.get("http://localhost:8080/usersrest//alertes_lues",{params:data});
  }
}
