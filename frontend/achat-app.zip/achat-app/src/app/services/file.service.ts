import { Injectable } from '@angular/core';
import {HttpClient, HttpEvent, HttpRequest} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(private http: HttpClient) { }

  /*uploadFile(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const req = new HttpRequest('POST', 'http://localhost:8080/annonces/files', formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }*/


  /*uploadFile(data : FormData,infos: any)  {
    //var data= {file:formdata};
    const req = new HttpRequest('POST', 'http://localhost:8080/annonces/files',data);
    return this.http.request(req);

}*/

  uploadFile(data : FormData)  {

    const req = new HttpRequest('POST', 'http://localhost:8080/annonces/files',data);
    return this.http.request(req);

  }

  uploadFileModif(data : FormData)  {

    const req = new HttpRequest('POST', 'http://localhost:8080/annonces//modif_annonce',data);
    return this.http.request(req);

  }

}
