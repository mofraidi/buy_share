import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  private listeConversation : any[];

  constructor(private httpClient : HttpClient) { }

  public getMyConvesation(id_user_src : any, id_user_des : any){
    let data = {idUserSource: id_user_src, idUserDesti : id_user_des};
    return this.httpClient.get("http://localhost:8080/message/conversation",{params : data});
  }

  public postMsg(id_usr_src : any, id_usr_des : any, message : any){
  let data =  {idUserSource:id_usr_src, idUserDesti:id_usr_des, msg:message};

   return this.httpClient.post("http://localhost:8080/message/msg_indiv", /*{params:data}*/{idUserSource:id_usr_src, idUserDesti:id_usr_des, msg:message});


  }

}
