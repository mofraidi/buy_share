import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InscriptionService {
  public messageConfirmation : string = "";

  constructor(private http: HttpClient) { }

  public getLocalitesJson(){
    return this.http.get("http://localhost:8080/localites/all");
  }

  public postUser(username : string, pass : string, email : string, localite_ : string){
    let data = {userName:username, passWord : pass, eMail : email,localite : localite_};
   return this.http.post("http://localhost:8080/usersrest/save_user", /*{params:data}*/{userName:username, passWord : pass, eMail : email,localite : localite_});

  }

  public userNameExists(username : string){
    let data = {userName : username};
    return this.http.get("http://localhost:8080/usersrest/username_exist",{params:data});
  }

  public userNameExistsObj(username : string){
    let data = {userName : username};
    return this.http.get("http://localhost:8080/usersrest/username_exist_obj",{params:data});
  }

  public eMailExists(email : string){
    let data = {eMail : email};
    return this.http.get("http://localhost:8080/usersrest/email_exist",{params:data});
  }



}
