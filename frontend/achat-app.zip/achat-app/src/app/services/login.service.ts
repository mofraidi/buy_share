import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Password} from 'primeng/primeng';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  messageConnexion:string = "";
  role:object[]=[{nom:"user"},{nom:"gestionnaire"},{nom:"admin"}];
  interface : string = "";


  constructor(private http: HttpClient) { }

  public returnInterface(userName : string){

    switch (userName) {
      case "user":
        return this.interface = "menu_user";
        break;
      case "gestionnaire":
        return this.interface = "menu_gestion";
        break;
      case "admin":
        return this.interface = "menu_admin";
        break;

    }

  }

  public checkUser(username:string, pass : string){
    let data = {userName:username, passWord:pass}
    return this.http.get("http://localhost:8080/usersrest/userCheck",{params :data});
  }

}
