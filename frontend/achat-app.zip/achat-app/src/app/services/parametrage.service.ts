import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ParametrageService {

  constructor(private http : HttpClient) { }

  public getParams(){
    return this.http.get("http://localhost:8080/parametres/liste_params");
  }



  public modifParam(id_param : any, nouv_valeur : any){
    let data = {idParam : id_param, nouvelleValeur : nouv_valeur};
    return this.http.get("http://localhost:8080/parametres/modif_param",{params:data});

  }

  public enregistrerParam(cle_ : any, valeur_: any){
    let data = {cle : cle_, valeur : valeur_};
    return this.http.get("http://localhost:8080/parametres/enregistrer_param",{params:data});
  }

}//eof
