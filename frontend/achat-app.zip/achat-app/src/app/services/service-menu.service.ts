import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceMenuService {

  /*public hideMenuUser :boolean=true;
  public hideMenuGestionnaire :boolean= true;
  public hideMenuAdmin : boolean =true;*/


  constructor() { }
}
