import { Component, OnInit } from '@angular/core';
import {CategorieService} from '../services/categorie.service';
import {Message} from 'primeng/api';

@Component({
  selector: 'app-gestion-categories',
  templateUrl: './gestion-categories.component.html',
  styleUrls: ['./gestion-categories.component.css']
})
export class GestionCategoriesComponent implements OnInit {

  msgCatExist : string = "";
  msgCatEnregistree : string = "";
  catExist : number = 0;
  nomCat : string = "";
  categories : any[];
  nomCatModif : string = "";
  selectedCat : string;
  btnEnregistrerDisabled : boolean = true;
  msgs: Message[] = [];

  constructor(private serviceCategorie : CategorieService) { }

  ngOnInit() {
    this.listeCategories();
  }

  public verifiSiCategorieExist(){
    this.msgCatExist="";
    this.serviceCategorie.verifiSiCategorieeExist(this.nomCat).subscribe((data => {
      // @ts-ignore
      var val = data;

      if(val == 1){this.msgCatExist = "nom de catégorie déjà existant!";this.catExist = 1}else {this.msgCatExist = "nom de catégorie disponible"; this.btnEnregistrerDisabled = false;}

    }));


  }

  public enregistrerNouvCategorie(){
    if (this.nomCat == null || this.catExist == 1){alert("le nom existe déjà ou champ vide !");this.catExist=0;return;}

    this.serviceCategorie.enregistrerNouvCat(this.nomCat).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){this.showSuccessEnr();}
      this.ngOnInit();

    }));
  }

  public listeCategories(){
    this.serviceCategorie.getListCategories().subscribe((data => {
      // @ts-ignore
      this.categories = data;

    }));
  }

  public modifierCategories(){
    if(this.selectedCat == null || this.nomCatModif == ""){alert("champ non validé") ; return;}
    this.serviceCategorie.modifierCategorie(this.selectedCat, this.nomCatModif).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){this.showSuccessMod();this.nomCatModif == "";this.ngOnInit();}

    }));
  }

  public suppCategorie(){
    if(this.selectedCat == null){alert("aucune catégorie selectionnée");}
    this.serviceCategorie.supprimerCategorie(this.selectedCat).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){this.showSuccessSup();this.ngOnInit();}

    }));
  }

  showSuccessMod() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'la catégorie a été modifiée !'});
  }

  showSuccessSup() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'la catégorie a été supprimée avec succès !'});
  }

  showSuccessEnr() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'la catégorie a été enregistrée avec succès !'});
  }





}// eof
