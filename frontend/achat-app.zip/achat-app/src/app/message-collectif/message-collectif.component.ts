import { Component, OnInit } from '@angular/core';
import {GroupeServiceService} from '../groupe-service.service';
import {SelectItem} from 'primeng/components/common/api';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-message-collectif',
  templateUrl: './message-collectif.component.html',
  styleUrls: ['./message-collectif.component.css']
})
export class MessageCollectifComponent implements OnInit {
  private userNamesMyGroupe : any[];
  private selectedUserNames : any[];
  private message : any;
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  msgs: Message[] = [];

  constructor(private serviceGroupe : GroupeServiceService, private messageService: MessageService) { }

  ngOnInit() {
    this.serviceGroupe.getMyMembersGroupeUserNames(this.userSession.id,this.serviceGroupe.selectedGroupe.id).subscribe((
      data =>
      { // @ts-ignore
        // @ts-ignore
        this.userNamesMyGroupe = data;
      }
    ));

    this.serviceGroupe.confirmationMsg = "";
  }

  public envoyerMsgCollectif(){

    console.log(this.selectedUserNames) ;
    this.serviceGroupe.envoyerMsgcollectif(this.message,this.selectedUserNames,this.serviceGroupe.selectedGroupe.id,this.userSession.id).subscribe((
      data =>
      { // @ts-ignore
        // @ts-ignore
        var val = data;
        if(val == 1) { this.showSuccess();}
      }
    ));

  }

  showSuccess() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'le message a été envoyé avec succès !'});
  }

}
