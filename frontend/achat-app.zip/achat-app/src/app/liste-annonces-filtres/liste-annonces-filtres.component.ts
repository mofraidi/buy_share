import {Component, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {AnnonceServiceService} from '../services/annonce-service.service';
import {any} from 'codelyzer/util/function';
import {DetailUserService} from '../services/detail-user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-liste-annonces-filtres',
  templateUrl: './liste-annonces-filtres.component.html',
  styleUrls: ['./liste-annonces-filtres.component.css']
})
export class ListeAnnoncesFiltresComponent implements OnInit{
  private annoncesFiltrees : any[];
  private listeUserNames : any[];
  private selectedCar: any;
  private displayDialog: boolean;
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  private btnJoindre : any = false;

  constructor(private service : AnnonceServiceService, private detailUserService : DetailUserService,private router : Router) { }

  ngOnInit() {

    this.service.getAnnoncesFiltreesJson(this.service.mot_cle,this.service.categ,this.service.code_postal,this.service.dist).subscribe((data => {
      // @ts-ignore
      this.annoncesFiltrees = data;

    }));



  }




  selectCar(event: Event, car: any) {
    this.selectedCar = car;
    this.displayDialog = true;

    this.service.getListeUserNamesAnnonce(this.selectedCar.articleDTO.id).subscribe((data => {
      // @ts-ignore
      this.listeUserNames = data;
    }));

    event.preventDefault();
  }

  onDialogHide() {
    this.selectedCar = null;
  }

  public joindreGroupe(id_user : any, id_article : any){
    this.service.joindreGroupe(id_user,id_article).subscribe((data => {
      // @ts-ignore
      var x = data;

      if(x == 1){this.btnJoindre=true}
    }));
  }

  public detaiUser(selectedUser : any ){
    this.detailUserService.selectedUser = selectedUser;

    this.router.navigate(["/user_detail"])
  }


}
