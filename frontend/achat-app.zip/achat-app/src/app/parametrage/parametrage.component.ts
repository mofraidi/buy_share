import { Component, OnInit } from '@angular/core';
import {ParametrageService} from '../services/parametrage.service';

@Component({
  selector: 'app-parametrage',
  templateUrl: './parametrage.component.html',
  styleUrls: ['./parametrage.component.css']
})
export class ParametrageComponent implements OnInit {
  private parametres : any[];
  private valeur : any;

  constructor(private service : ParametrageService) { }

  ngOnInit() {

    this.service.getParams().subscribe((data => {
      // @ts-ignore
      this.parametres = data;

    }));
  }

  public modifierValeurDeCle(param : any){
    var nouvelleValeur = (<HTMLInputElement>  document.getElementById(param.cle)).value;
    this.service.modifParam(param.id,nouvelleValeur).subscribe((data => {
      // @ts-ignore
      var val = data;
      if(val == 1){
        alert("la valeur a été modifiée");
        this.ngOnInit();
      }

    }));
  }


  public sauvegarderValeurCle(){
    var cs = (<HTMLInputElement>  document.getElementById("cleS")).value;
    var vs = (<HTMLInputElement>  document.getElementById("valeurS")).value;
    this.service.enregistrerParam(cs,vs).subscribe((data) => {
      // @ts-ignore
      var val = data;
      {alert("la valeur a été sauvegardée");this.ngOnInit();}

    },
      (error) => {
          alert("erreur innatendue, ou nom de clé deja existant!");

        }
    );
    (<HTMLInputElement>  document.getElementById("cleS")).value = "";
    (<HTMLInputElement>  document.getElementById("valeurS")).value="";

  }


}//eof
