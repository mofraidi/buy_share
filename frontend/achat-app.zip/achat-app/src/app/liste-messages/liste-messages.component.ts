import { Component, OnInit } from '@angular/core';
import {MessageService} from '../services/message.service';
import {DetailUserComponent} from '../detail-user/detail-user.component';
import {DetailUserService} from '../services/detail-user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-liste-messages',
  templateUrl: './liste-messages.component.html',
  styleUrls: ['./liste-messages.component.css']
})
export class ListeMessagesComponent implements OnInit {

  private maConversation : any[];
  private userSession :any = JSON.parse(sessionStorage.getItem('user'));
  private msg : string;
  private idUserD : any = 27;
  private idUserS : any = this.userSession.id;
  private message : string;



  constructor(private serviceMsg : MessageService, private detailUserService : DetailUserService,private router:Router) { }

  ngOnInit() {

    this.serviceMsg.getMyConvesation(this.userSession.id,this.detailUserService.selectedUser.id).subscribe((data => {
      // @ts-ignore
      this.maConversation = data;


    }));

  }

  public envoyerMsgInd(idUserSrc : any, idUserDest, msg : string){
    this.serviceMsg.postMsg(this.detailUserService.selectedUser.id,this.userSession.id,msg).subscribe((data => {
      // @ts-ignore
      this.ngOnInit();

    }));


  }

}
