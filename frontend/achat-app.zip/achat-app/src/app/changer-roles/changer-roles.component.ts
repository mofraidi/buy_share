import { Component, OnInit } from '@angular/core';
import {RoleService} from '../services/role.service';
import {InscriptionService} from '../services/inscription.service';
import {Message} from 'primeng/api';

@Component({
  selector: 'app-changer-roles',
  templateUrl: './changer-roles.component.html',
  styleUrls: ['./changer-roles.component.css']
})
export class ChangerRolesComponent implements OnInit {

  private roles : any[];
  private userName : string = "";
  private user : any;
  private selectedRole : string;
  private userNameExistMsg : string = "";
  private btnDisabled : boolean = true;
  private msgs: Message[] = [];

  constructor(private serviceRole : RoleService, private serviceIns : InscriptionService) {

  }

  ngOnInit() {
    this.listeRoles();
    this.userName = "";

  }

  public listeRoles(){
    this.serviceRole.getListRoles().subscribe((data => {
      // @ts-ignore
      this.roles = data;

    }));
  }

  public userNameExists(){

    var val : number;
    this.serviceIns.userNameExistsObj(this.userName).subscribe((data => {

      var val = data;

      if(val != null){this.user = data;this.userNameExistMsg = "username existant avec rôle : "+this.user.role.nom; this.btnDisabled=false;}
      else{this.userNameExistMsg = "username non existant!"; this.btnDisabled=true;}

    }));
  }

  public mouseEnter(){
    this.userNameExistMsg = "";
  }

  public changerRole(){


    if(this.userName == "" || this.selectedRole == null){alert("un ou plusieurs champs sont vides !"); return;}
    if(this.selectedRole == this.user.role.nom){alert("le rôle choisis doit étre different du rôle actuel de l 'user "+"'"+this.user.role.nom+"'"); return;}
    this.serviceRole.changerRoleUser(this.userName, this.selectedRole).subscribe((data => {

      var val = data;

      if(val == 1){this.showSuccess(); this.userNameExistMsg = "";}

    }));
  }

  showSuccess() {
    this.msgs = [];
    this.msgs.push({severity:'success', summary:'Success Message', detail:'le changement a été fait avec succès !'});
  }



}// eof
