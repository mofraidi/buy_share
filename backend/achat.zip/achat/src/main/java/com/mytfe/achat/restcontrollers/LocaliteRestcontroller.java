package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.LocaliteRepository;
import com.mytfe.achat.dto.LocaliteDTO;
import com.mytfe.achat.metier.Localite;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/localites")
public class LocaliteRestcontroller {
    @Autowired
    LocaliteRepository tr;
    ModelMapper modelMapper = new ModelMapper();

   @GetMapping("all") // localites/all
    public List<LocaliteDTO> allLocalites(){

        List<LocaliteDTO> localitesDTO = new ArrayList();
        for(Localite localite : tr.findAll(Sort.by(Sort.Direction.ASC, "nom"))){
            LocaliteDTO localiteDTO = modelMapper.map(localite,LocaliteDTO.class);
            localitesDTO.add(localiteDTO);
        }
        return localitesDTO;

    }
}
