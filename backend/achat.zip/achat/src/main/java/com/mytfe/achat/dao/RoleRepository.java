package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository extends JpaRepository <Role, Long> {
    public Optional<Role> findBynom(String nom);
}

