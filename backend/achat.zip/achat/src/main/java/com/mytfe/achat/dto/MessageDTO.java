package com.mytfe.achat.dto;

import lombok.*;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(of ={"id"})
public class MessageDTO {

    private Long id;
    private LocalDateTime date_heure_publi;
    private String contenu;
    private Boolean lu;
    private UserDTOLight  userDTOSource;


}
