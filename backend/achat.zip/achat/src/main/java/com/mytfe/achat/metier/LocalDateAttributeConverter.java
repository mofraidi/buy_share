package com.mytfe.achat.metier;

import javax.persistence.AttributeConverter;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;


public class LocalDateAttributeConverter implements AttributeConverter<LocalDateTime, Timestamp> {



    @Override
    public Timestamp  convertToDatabaseColumn(LocalDateTime locaDateTime) {
        return locaDateTime == null ? null : Timestamp.valueOf(locaDateTime);
    }

    @Override
    public LocalDateTime convertToEntityAttribute(Timestamp sqlTimestam) {
        return sqlTimestam == null ? null : sqlTimestam.toLocalDateTime();
    }

}
