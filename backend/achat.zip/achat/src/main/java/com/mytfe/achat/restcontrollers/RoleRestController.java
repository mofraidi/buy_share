package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.RoleRepository;
import com.mytfe.achat.metier.Role;
import com.mytfe.achat.metier.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
//@RequestMapping("/rolesrest")
@RequestMapping(value = "/rolesrest" , method = RequestMethod.GET )

public class RoleRestController {
    @Autowired
    RoleRepository rr;

    @RequestMapping (value = "/liste" , method = RequestMethod.GET ) //rolesrest/liste
    public List<Role> listeRoles(){
        List listeRoles = rr.findAll();
        return listeRoles;
    }

    @GetMapping("/role_exist") // rolesrest/role_exist
    public int verifiSiRoleExist(@RequestParam String nomRole){

        Optional<Role> op = rr.findBynom(nomRole);
        if(op.isPresent()){return 1;}
        return 0;

    }

    @GetMapping("/enregist_role") // rolesrest/enregist_role
    public int enregistrerRole(@RequestParam String nomRole){

        rr.save(new Role(nomRole));
        return 1;

    }

    @GetMapping("/modifier_role") // rolesrest/modifier_role
    public int modifierRole(@RequestParam String nomRole, @RequestParam String nouvNomRole){
        Optional<Role> opR = rr.findBynom(nomRole);
        Role role = opR.get();
        role.setNom(nouvNomRole);
        rr.save(role);
        return 1;


    }

    @GetMapping("/supp_role") // rolesrest/supp_role
    public int supprimerRole(@RequestParam String nomRole){
        Optional<Role> opR = rr.findBynom(nomRole);
        rr.deleteById(opR.get().getId());
        return 1;

    }







}
