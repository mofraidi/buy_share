package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Blocage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BlocageRepository extends JpaRepository <Blocage,Long> {

}
