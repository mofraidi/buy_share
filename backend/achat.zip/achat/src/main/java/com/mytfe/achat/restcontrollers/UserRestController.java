package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.*;
import com.mytfe.achat.dto.AdhesionDTO;
import com.mytfe.achat.dto.AnnonceDTO;
import com.mytfe.achat.dto.UserDTO;
import com.mytfe.achat.interfaces.DtoUtil;
import com.mytfe.achat.metier.*;
import org.mindrot.jbcrypt.BCrypt;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@CrossOrigin
@RestController
@RequestMapping("/usersrest")
public class UserRestController implements DtoUtil<UserDTO,User> {
    private static final String DATE_FORMATTER= "yyyy-MM-dd HH:mm:ss";
    @Autowired UserRepository ur;
    @Autowired AdhesionRepository ar;
    @Autowired GroupeRepository gr;
    @Autowired LocaliteRepository lr;
    @Autowired BlocageRepository br;
    @Autowired RoleRepository rr;
    @Autowired BlocageRepository blr;
    @Autowired public JavaMailSender emailSender;



    ModelMapper modelMapper = new ModelMapper();




    @RequestMapping (value = "/userCheck" , method = RequestMethod.GET )// usersrest/userCheck
    public UserDTO userCheck(@RequestParam String userName,@RequestParam String passWord){

        Optional<User> op =  ur.findByuserName(userName);
        if(op.isPresent() )  {
            if(BCrypt.checkpw(passWord,op.get().getPassWord()) && op.get().isConfirmation()){return affecterDAO(op.get());}

        }

        return null;
    }

    @PostMapping("/save_user") // usersrest/save_user

    public int  postUser(@RequestBody Map<String,String> body){

        Optional<Localite> opL = lr.findBynom(body.get("localite"));

        Optional<Blocage> opB = br.findById(Long.valueOf(1));
        Optional<Role> opR =  rr.findById(Long.valueOf(1));
        String pw = body.get("passWord");

        String pw_hash = BCrypt.hashpw(pw,BCrypt.gensalt());
        User user = new User(body.get("userName"),pw_hash,body.get("eMail"));
        String codeConfirmation = codeConfirmation(10);
        Long id = user.getId();

        user.setBlocage(opB.get());
        user.setLocalite(opL.get());
        user.setDateHeureInscription(LocalDateTime.now());
        user.setRole(opR.get());
        user.setConfirmation(false);
        user.setCodeConfirmation(codeConfirmation);
        User user1 = ur.save(user);

        String url = "https://f883c7ca.ngrok.io/usersrest/confirmation?codeConfirmation="+codeConfirmation+"&idUser="+user1.getId();



       sendMail(url,body.get("eMail"));

        return 1;




    }

    @GetMapping("/confirmation") //usersrest/confirmation
    public String confirmationEmail(@RequestParam String codeConfirmation, Long idUser){
      Optional<User> op = ur.findById(idUser);


      if(op.isPresent()){

      if(op.get().isConfirmation()){return "user deja inscrit et confirmé";}
      else{
          if(op.get().getCodeConfirmation().equals(codeConfirmation)){
              User user = op.get();
              user.setConfirmation(true);
              user.setCodeConfirmation(null);
              ur.save(user);

              return "felicitation ,votre inscription a été confirmée!";
          }
          else{return "code confirmation incorrecte";}
      }

      }
      else {return "user not present!";}


    }

    public void sendMail (String url, String eMail){

        // Create a Simple MailMessage.
        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(eMail);
        message.setSubject("Test Simple Email");
        message.setText("Veuillez confirmer votre inscription en cliquant sur le lien : "+url);

        // Send Message!
        this.emailSender.send(message);

    }

    public String codeConfirmation(int taille){

        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz";


        StringBuilder sb = new StringBuilder(taille);

        for (int i = 0; i < taille; i++) {


            int index
                    = (int)(AlphaNumericString.length()
                    * Math.random());


            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }
    @GetMapping("/username_exist") // usersrest/username_exist
    public int verifiSiUsernameExist(String userName){

        Optional<User> op = ur.findByuserName(userName);
        if(op.isPresent()){return 1;}
        return 0;

    }

    @GetMapping("/username_exist_obj") // usersrest/username_exist_obj
    public User verifiSiUsernameExistObjet(@RequestParam String userName){

        Optional<User> op = ur.findByuserName(userName);
        if(op.isPresent())
        {User user = new User();
        user.setRole(op.get().getRole());
        user.setUserName(op.get().getUserName());
        user.setBlocage(op.get().getBlocage());
        return user;
        }
        return null;

    }

    @GetMapping("/email_exist") // usersrest/email_exist
    public int verifySiEmailExist(String eMail){
        Optional<User> op = ur.findByemail(eMail);
        if(op.isPresent()){return 1;}
        return 0;
    }

    @GetMapping("/mes_alertes") // users_rest/mes_alertes
    public List<Alerte> mesAlertes(@RequestParam String userName){
        Optional <User> opU = ur.findByuserName(userName);
        return opU.get().getAlertes();
    }

    @GetMapping("/alertes_lues") // usersrest/alertes_lues
    public int alertesLues(@RequestParam String userName){
        Optional <User> opU = ur.findByuserName(userName);
        User user = opU.get();
        for(Alerte alerte : user.getAlertes()){
            alerte.setLu(true);
        }
        ur.save(user);
        return 1;
    }

    @GetMapping("/demandes") // usersrest/demandes
    public List<Adhesion> demandesNonApprouvee(@RequestParam String userName){
        Optional<User> opU = ur.findByuserName(userName);
        List<Adhesion> adhesions = ar.adhesionsNonApprouvee(opU.get().getId());
        List<Adhesion> adhesions1 = new ArrayList<>();
        for(Adhesion adhesion: adhesions){
            Adhesion ad = new Adhesion();
            User user = new User();
            user.setUserName(adhesion.getUser().getUserName());
            Groupe groupe = new Groupe();
            groupe.setId(adhesion.getGroupe().getId());
            Article article = new Article();
            article.setNom(adhesion.getGroupe().getArticle().getNom());
            groupe.setArticle(article);
            adhesion.setUser(user);
            adhesion.setGroupe(groupe);
            adhesions1.add(adhesion);

        }
       return adhesions1;

    }
    @GetMapping("/maj_role") // usersrest/maj_role
    public int mettreAJourRole(@RequestParam String userName,@RequestParam String nomRole){
        Optional<User> opU = ur.findByuserName(userName);
        Optional<Role> opR = rr.findBynom(nomRole);
        if(opU.isPresent() == false || opR.isPresent() == false){return 0;}
        User user = opU.get();
        user.setRole(opR.get());
        ur.save(user);
        return 1;
    }

    @GetMapping("/bloquer_user") // usersrest/bloquer_user
    public int bloquerUser(@RequestParam Long idUser,@RequestParam int nbrHeuresBlocage){
        Optional<User> op = ur.findById(idUser);
        User user = op.get();
        Blocage blocage = new Blocage(true,LocalDateTime.now(),nbrHeuresBlocage);
        ur.save(user);
        return 1;

    }
    @GetMapping("/debloquer_user") // usersrest/debloquer_user
    public int debloquerUser(@RequestParam Long idUser){
        Optional<User> op = ur.findById(idUser);
        User user = op.get();
        Optional<Blocage> opB = blr.findById(Long.valueOf(1));
        user.setBlocage(opB.get());
        ur.save(user);
        return 1;

    }


    @Override
    public UserDTO affecterDAO(User user) {
        UserDTO userDTO = modelMapper.map(user,UserDTO.class);
        List<AdhesionDTO> listeAdhDTO = new ArrayList<>();
        List<AnnonceDTO> listAnnoncesDTO = new ArrayList<>();
        if(user.getAdhesions().size()>0){

            for(Adhesion ad : user.getAdhesions()){
                AdhesionDTO adhDTO = modelMapper.map(ad,AdhesionDTO.class);
                listeAdhDTO.add(adhDTO);

            }

            userDTO.setAdhesions(listeAdhDTO);

        }
        if(user.getAnnonces().size()>0){

            for(Annonce annonce : user.getAnnonces()){
                AnnonceDTO annonceDTO = modelMapper.map(annonce, AnnonceDTO.class);
                listAnnoncesDTO.add(annonceDTO);
            }

            userDTO.setAnnoncesDTO(listAnnoncesDTO);

        }


        return userDTO;




    }


}//eof

