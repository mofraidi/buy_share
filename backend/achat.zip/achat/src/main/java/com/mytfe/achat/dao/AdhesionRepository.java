package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Adhesion;

import com.mytfe.achat.metier.Groupe;
import com.mytfe.achat.metier.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AdhesionRepository extends JpaRepository<Adhesion, Long> {

    @Query(value = "SELECT * from adhesion", nativeQuery = true)
    List<Adhesion> listeAdhesioNative();

    @Query(value = "SELECT * \n" +
            "FROM adhesions\n" +
            "WHERE id_groupe = :id \n" +
            "ORDER BY date_debut_utilisation desc,IF(ISNULL(date_heure_reservation),1,0),date_heure_reservation asc  ", nativeQuery = true)
    List<Adhesion> listeAdhesioOrdered(@Param(value = "id")Long id);



    Adhesion findByUserAndGroupe(User user, Groupe groupe);

     @Query(value = "select * from adhesions where exists(select * from groupes where id_user_createur =:id_usr)\n" +
             "and approuvee = 0\n" +
             "and id_user <>:id_usr", nativeQuery = true)
    List<Adhesion> adhesionsNonApprouvee(@Param (value ="id_usr")Long id_usr);



}
