package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name="commentaires")
public class Commentaire {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private String contenu;
    @Column(name = "date_heure_publi")
    private LocalDateTime datePublication;
    @ManyToOne
    @JoinColumn(name="id_user_publicateur")
    private User userSource;
    @ManyToOne
    @JoinColumn(name="id_user_concerne")
    private User userDestination;
    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "users_signale_comments",
            joinColumns = @JoinColumn(name = "id_comment"),
            inverseJoinColumns = @JoinColumn(name = "id_user"))
    private List<User> usersSignals = new ArrayList<User>();
    @ManyToOne
    @JoinColumn(name="id_article")
    private Article article = new Article();


    public Commentaire(String contenu, LocalDateTime datePublication, User userSource, User userDestination, Article article) {
        this.contenu = contenu;
        this.datePublication = datePublication;
        this.userSource = userSource;
        this.userDestination = userDestination;
        this.article = article;
    }
}
