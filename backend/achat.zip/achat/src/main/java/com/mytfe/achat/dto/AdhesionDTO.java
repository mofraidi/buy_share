package com.mytfe.achat.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mytfe.achat.metier.AffichageAdhesion;
import com.mytfe.achat.objets.AffichageJoursHeures;
import lombok.*;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;

@Data @AllArgsConstructor  @NoArgsConstructor

public class AdhesionDTO {

    UserDTO userDTO;
    GroupeDTO groupeDTO;
    @Nullable
    @JsonFormat(pattern = "dd-MM-yyyy HH:mm")

    private LocalDateTime dateReservation;
    @Nullable
    //@JsonFormat(pattern = "dd-MM-yyyy HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime dateDebutUtilisation;
    private int nbrHeuresPenalisation;
    private int nbrHeuresUtilisation;
    private AffichageJoursHeures affichageJoursHeures;
    private AffichageJoursHeures delaiUtilisationJH;
    private AffichageJoursHeures nbrHeuresPenalisationJH;




}
