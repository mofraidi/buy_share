package com.mytfe.achat.interfaces;

public interface DtoUtil <T,D> {
    public T affecterDAO(D d);
}
