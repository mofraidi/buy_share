package com.mytfe.achat.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor
public class ArticleDTO {

    private Long id;
    private String nom;
    private String description;
    private Double prix;
    private String delaiUtilisation ;
    private int delaiMinUtilisation;
    private int delaiTransition;

    private CategorieDTO categorie;
    private List<RessourceDTO> ressourcesDTO;
    //TODO

}
