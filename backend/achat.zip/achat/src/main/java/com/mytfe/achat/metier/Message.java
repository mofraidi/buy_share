package com.mytfe.achat.metier;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor @ToString @EqualsAndHashCode(of ={"id"})
@Entity
@Table(name = "messages")
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "date_heure_publi")
    private LocalDateTime date_heure_publi;
    @Column
    private String contenu;
    @Column
    private Boolean lu;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "id_user_src")
    private User userSource;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "id_groupe")
    private Groupe groupe;
    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "messages_users",
            joinColumns = @JoinColumn(name = "id_message"),
            inverseJoinColumns = @JoinColumn(name = "id_user_dest"))
    private List<User> usersDest = new ArrayList();

    public Message(LocalDateTime date_heure_publi, String contenu, Boolean lu, User userSource, Groupe groupe, List<User> usersDest) {
        this.date_heure_publi = date_heure_publi;
        this.contenu = contenu;
        this.lu = lu;
        this.userSource = userSource;
        this.groupe = groupe;

        this.usersDest = usersDest;
    }
}
