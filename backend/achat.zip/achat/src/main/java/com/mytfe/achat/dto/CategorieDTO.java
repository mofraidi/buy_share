package com.mytfe.achat.dto;

public class CategorieDTO {
}
