package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.ArticleRespository;
import com.mytfe.achat.dao.CommentaireRepository;
import com.mytfe.achat.dao.UserRepository;
import com.mytfe.achat.metier.Article;
import com.mytfe.achat.metier.Commentaire;
import com.mytfe.achat.metier.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/commentaires")
public class CommentaireRestController {
    @Autowired CommentaireRepository cr;
    @Autowired UserRepository ur;
    @Autowired ArticleRespository ar;


    @GetMapping("ecrire_comment")
    public int ecrireCommentaire(@RequestParam Long idUserDest,@RequestParam String contenu, @RequestParam Long idUserSource,@RequestParam Long idArticle){
       Optional<User> opUD = ur.findById(idUserDest);
       Optional<User> opUS = ur.findById(idUserSource);
       Optional<Article> opAR = ar.findById(idArticle);
       if( !( opAR.isPresent() && opUD.isPresent() && opUS.isPresent() ) ){return 0;}
       Commentaire commentaire = new Commentaire(contenu, LocalDateTime.now(),opUS.get(),opUD.get(),opAR.get());
       cr.save(commentaire);
       return 1;

    }

    @GetMapping("/signaler_comment")
    public int signalerCommentaire(@RequestParam Long idComment,@RequestParam Long idUserSignal){

        Optional<Commentaire> opC = cr.findById(idComment);
        Optional<User> opUS = ur.findById(idUserSignal);
        if(!( opC.isPresent() && opUS.isPresent() )){return 0;}
        Commentaire commentaire = opC.get();
        commentaire.getUsersSignals().add(opUS.get());
        cr.save(commentaire);
        return 1;


    }

    @GetMapping("supp_comment")
    public int supprimerCommentaire(@RequestParam Long idCommentaire){
        Optional<Commentaire> opC = cr.findById(idCommentaire);
        if(!opC.isPresent()){return 0;}
        cr.delete(opC.get());
        return 1;


    }

}
