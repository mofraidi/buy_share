package com.mytfe.achat.dto;

import com.mytfe.achat.metier.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.OrderBy;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor
public class GroupeDTO {
    private Long id;
    private boolean etat;
    private UserDTO userCreateur;
    @OrderBy("dateHeureReservation")
    private ArticleDTO article;
    private List<AdhesionDTO> adhesions;
}
