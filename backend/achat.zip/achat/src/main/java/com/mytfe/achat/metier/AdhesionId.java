package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import java.io.Serializable;
import java.util.Objects;

@Getter
@NoArgsConstructor
@AllArgsConstructor @EqualsAndHashCode(of ={"idUser","idGroupe"})

@Embeddable
public class AdhesionId implements Serializable {

    @Column (name = "id_user")
    private Long idUser;


    @Column (name = "id_groupe")
    private Long idGroupe;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdhesionId that = (AdhesionId) o;
        return idUser.equals(that.idUser) &&
                idGroupe.equals(that.idGroupe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUser, idGroupe);
    }
}
