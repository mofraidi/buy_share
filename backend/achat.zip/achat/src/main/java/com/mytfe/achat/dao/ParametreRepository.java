package com.mytfe.achat.dao;


import com.mytfe.achat.metier.Parametre;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ParametreRepository extends JpaRepository<Parametre,Long> {

    Optional<Parametre> findByCle(String cle);

}
