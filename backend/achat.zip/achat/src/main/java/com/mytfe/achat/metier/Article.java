package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name = "articles")
public class Article implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private String nom;
    @Column
    private String description;
    @Column
    private Double prix;
    @Column (name = "delai_utilisation")
    private int delaiUtilisation ;
    @Column (name = "delai_min_utilisation")
    private int delaiMinUtilisation;
    @Column (name = "delaiTransition")
    private int delaiTransition;
    @ManyToOne
    @JoinColumn(name="id_categorie")
    private Categorie categorie;
    @OneToMany(mappedBy = "article", cascade = CascadeType.ALL)
    private List<Ressource> ressources = new ArrayList<>();


    public Article(String nom, String description, Double prix, int delaiUtilisation, int delaiMinUtilisation, int delaiTransition, Categorie categorie) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
        this.delaiUtilisation = delaiUtilisation;
        this.delaiMinUtilisation = delaiMinUtilisation;
        this.delaiTransition = delaiTransition;
        this.categorie = categorie;
    }
}
