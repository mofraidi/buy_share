package com.mytfe.achat.metier;

import com.mytfe.achat.objets.AffichageJoursHeures;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Objects;

@Data @AllArgsConstructor @NoArgsConstructor

public class AffichageAdhesion extends Adhesion {

    AffichageJoursHeures delaiUtilisationJH;
    AffichageJoursHeures nbrHeuresPenalisationJH;


    public AffichageAdhesion(AdhesionId id, User user, Groupe groupe, boolean approuvee, LocalDateTime dateHeureAdh, LocalDateTime dateDebutUtilisation, LocalDateTime dateHeureReservation, int nbrHeuresPenalisation, int nbrHeuresUtilisation, AffichageJoursHeures affichageJoursHeures) {
        super(id, user, groupe, approuvee, dateHeureAdh, dateDebutUtilisation, dateHeureReservation, nbrHeuresPenalisation, nbrHeuresUtilisation, affichageJoursHeures);
    }
}
