package com.mytfe.achat.dto;

import com.mytfe.achat.metier.Localite;
import com.mytfe.achat.metier.Role;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


@Data @AllArgsConstructor @NoArgsConstructor
public class UserDTO implements Comparable{
    Long id;
    String userName;
    private Localite localite;
    private Role role;
    List<AdhesionDTO> adhesions;
    List<AnnonceDTO> annoncesDTO;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserDTO userDTO = (UserDTO) o;
        return Objects.equals(id, userDTO.id) &&
                Objects.equals(userName, userDTO.userName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userName);
    }

    @Override
    public int compareTo(Object o) {
       /* UserDTO ad = (UserDTO) o;

        if(this.getAdhesions().getDateDebutUtilisation() != null && this.getAdhesions().getDateReservation() == null) return 1;
        return this.getAdhesion().getDateReservation().compareTo((((UserDTO) o).getAdhesion().getDateReservation()));
*/      return 0;

    }
}
