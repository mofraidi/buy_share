package com.mytfe.achat.metier;

import com.mytfe.achat.dto.AnnonceDTO;
import com.mytfe.achat.interfaces.DtoUtil;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data @AllArgsConstructor @NoArgsConstructor @ToString @EqualsAndHashCode(of ={"id"})
@Entity
@Table(name = "annonces")
public class Annonce implements Serializable  {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    @Column
    String titre;
    @Column
    String description;
    @Column(name = "date_heure_pub")
    LocalDateTime dateHeurePublication;
    @Column(name = "nbr_min_membres")
    int nbrMinMemmbres;
    @Column(name = "nbr_max_membres")
    int nbrMaxMembres;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "id_article")
    Article article;
    @ManyToOne
    @JoinColumn(name="id_user_publicateur")
    User userPublicateur;

    public Annonce(String titre, String description, LocalDateTime dateHeurePublication, int nbrMinMemmbres, int nbrMaxMembres, Article article, User userPublicateur) {
        this.titre = titre;
        this.description = description;
        this.dateHeurePublication = dateHeurePublication;
        this.nbrMinMemmbres = nbrMinMemmbres;
        this.nbrMaxMembres = nbrMaxMembres;
        this.article = article;
        this.userPublicateur = userPublicateur;
    }
}

