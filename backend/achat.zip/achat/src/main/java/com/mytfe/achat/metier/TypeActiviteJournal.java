package com.mytfe.achat.metier;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name = "types_activ_journal")
public class TypeActiviteJournal {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private String nom;

    public TypeActiviteJournal(String nom) {
        this.nom = nom;
    }
}
