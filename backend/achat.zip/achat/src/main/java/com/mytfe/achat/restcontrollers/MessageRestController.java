package com.mytfe.achat.restcontrollers;

import com.mytfe.achat.dao.GroupeRepository;
import com.mytfe.achat.dao.MessageRepository;
import com.mytfe.achat.dao.UserRepository;
import com.mytfe.achat.dto.MessageDTO;
import com.mytfe.achat.dto.UserDTOLight;
import com.mytfe.achat.interfaces.DtoUtil;
import com.mytfe.achat.metier.Groupe;
import com.mytfe.achat.metier.Message;
import com.mytfe.achat.metier.User;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping(value = "/message" , method = RequestMethod.GET )

public class MessageRestController implements DtoUtil<MessageDTO,Message> {
    @Autowired UserRepository ur;
    @Autowired GroupeRepository gr;
    @Autowired MessageRepository mr;
    ModelMapper modelMapper = new ModelMapper();

    @GetMapping("/msg_coll")
    public int envoyerMessageCollectif(@RequestParam String msg, @RequestParam String[] userNames, @RequestParam Long idGroupe,@RequestParam Long idUserSource){

        if(userNames.length == 0 || idUserSource == null || msg == null){ return 0; }
        Optional<User> opU = ur.findById(idUserSource);
        Groupe groupe = null;

        if(idGroupe != null){Optional <Groupe> opG = gr.findById(idGroupe);groupe = opG.get();}
        List<User> usersDes = new ArrayList<>();
        for(int i = 0;i<userNames.length;i++){
         Optional<User> op = ur.findByuserName(userNames[i]);
         usersDes.add(op.get());
        }
        Message message = new Message(LocalDateTime.now(),msg,false,opU.get(),groupe,usersDes);
        mr.save(message);
        return 1;
    }



    @PostMapping("/msg_indiv")  // message/msg_indiv
    public List<MessageDTO> envoyerMessageIndividuel(@RequestBody Map<String,String> body ){

        String msg = body.get("msg");
        Long idUserSource = Long.valueOf(body.get("idUserSource"));
        Long idUserDesti = Long.valueOf(body.get("idUserDesti"));


        if(msg == null || idUserDesti == null || idUserSource == null){return null;}
        Optional<User> opUS = ur.findById(idUserSource);
        Optional<User> opUD = ur.findById(idUserDesti);
        List<User> usersDest = new ArrayList<>();
        usersDest.add(opUD.get());

        Message message = new Message(LocalDateTime.now(),msg,false,opUS.get(),null,usersDest);
        mr.save(message);
        /////////
        // envoyer la conversation actualisée
        List<Message> conversation = mr.dualConversation(idUserSource,idUserDesti);
        List<MessageDTO>conversationLight = new ArrayList<>();
        for(Message msg1 : conversation){
            MessageDTO msgDTO = affecterDAO(msg1);
            conversationLight.add(msgDTO);
        }
        return conversationLight;

    }


    @Override
    public MessageDTO affecterDAO(Message message) {
        User user = message.getUserSource();
        UserDTOLight userDTOLight = modelMapper.map(user, UserDTOLight.class);
        MessageDTO msgDTO = modelMapper.map(message, MessageDTO.class);
        msgDTO.setUserDTOSource(userDTOLight);
        return msgDTO;
    }

    @GetMapping("/conversation")
    public List<MessageDTO> conversation(@RequestParam Long idUserSource, @RequestParam Long idUserDesti){
        List<Message> conversation = mr.dualConversation(idUserSource,idUserDesti);
        List<MessageDTO>conversationLight = new ArrayList<>();
        for(Message msg1 : conversation){
            MessageDTO msgDTO = affecterDAO(msg1);
            conversationLight.add(msgDTO);
        }
        return conversationLight;
    }

}//eof
