package com.mytfe.achat.objets;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AffichageJoursHeures {
    int jours;
    int heures;
}

