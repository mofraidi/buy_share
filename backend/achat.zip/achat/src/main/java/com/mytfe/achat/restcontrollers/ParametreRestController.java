package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.ParametreRepository;
import com.mytfe.achat.metier.Parametre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping(value = "/parametres" , method = RequestMethod.GET )
public class ParametreRestController {
    @Autowired
    ParametreRepository pr;

    @GetMapping("/liste_params") // parametres/liste_params

    public List<Parametre> listeParametres(){
        return pr.findAll();

    }

    @GetMapping("/modif_param")
    public int ModifierParam(@RequestParam Long idParam, @RequestParam String nouvelleValeur){
        Optional<Parametre> opP = pr.findById(idParam);
        Parametre parametre = opP.get();
        parametre.setValeur(nouvelleValeur);
        pr.save(parametre);
        return 1;

    }
    @GetMapping("/enregistrer_param")
    public int enregistrerParam(@RequestParam String cle, @RequestParam String valeur){

        Parametre parametre = new Parametre(cle, valeur);
        pr.save(parametre);
        return 1;
    }

    @GetMapping("/verifi_cle")
    public boolean verifiSiCleExist(@RequestParam String cle ){
        Optional<Parametre> opP = pr.findByCle(cle);
        return opP.isPresent();

    }


}
