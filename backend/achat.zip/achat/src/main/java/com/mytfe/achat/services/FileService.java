package com.mytfe.achat.services;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;


@Component
public class FileService {

    private static final String IMAGE_DIRECTORY = "src/main/resources/static";

    public String storeFile(MultipartFile file, String username) throws IOException {

        String nouvNomFichier = codeConfirmation(6)+file.getOriginalFilename();
        File directory = new File(IMAGE_DIRECTORY);
        Path filePath = Paths.get(directory + "/" + nouvNomFichier);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        return nouvNomFichier;

    }

    public void deleteRessource(String nomRessource) throws IOException {
        Path path = Paths.get(IMAGE_DIRECTORY+"/"+nomRessource);
        if (Files.exists(path)){ Files.delete(path);}

    }


    public String codeConfirmation(int taille){

        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz";


        StringBuilder sb = new StringBuilder(taille);

        for (int i = 0; i < taille; i++) {

            int index
                    = (int)(AlphaNumericString.length()
                    * Math.random());

            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }


}
