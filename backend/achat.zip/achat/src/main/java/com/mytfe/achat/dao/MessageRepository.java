package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {


    @Query(value = "select distinct m.id,m.date_heure_publi,m.contenu,m.lu,m.id_user_src,m.id_groupe from messages as m, messages_users as mu where m.id = mu.id_message and m.id_user_src in (:id_src,:id_des)and mu.id_user_dest in (:id_src,:id_des) order by m.date_heure_publi asc", nativeQuery = true)
    List<Message> dualConversation(@Param(value ="id_src")Long idUserSrc, @Param(value ="id_des")Long idUserDesti);

}
