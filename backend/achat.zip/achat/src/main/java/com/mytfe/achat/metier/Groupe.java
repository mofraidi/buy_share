package com.mytfe.achat.metier;

import lombok.*;
import sun.awt.image.ImageWatched;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString @EqualsAndHashCode(of ={"id"})

@Entity
@Table(name = "groupes")
public class Groupe implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private boolean etat;
    @ManyToOne
    @JoinColumn(name = "id_article")
    private Article article;
    @ManyToOne
    @JoinColumn(name = "id_user_createur")
    private User userCreateur;
    @OneToMany(mappedBy = "groupe", cascade = CascadeType.ALL)
    //@OrderBy("dateDebutUtilisation desc  ,dateHeureReservation asc ")
    private List<Adhesion> membres = new ArrayList<>();

    public Groupe(boolean etat, Article article, User userCreateur, List<Adhesion> membres) {
        this.etat = etat;
        this.article = article;
        this.userCreateur = userCreateur;
        this.membres = membres;
    }
}
