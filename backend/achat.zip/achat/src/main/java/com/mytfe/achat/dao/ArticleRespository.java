package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticleRespository extends JpaRepository<Article,Long> {
}
