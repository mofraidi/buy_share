package com.mytfe.achat.metier;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor @ToString @EqualsAndHashCode(of ={"id"})
@Entity
@Table(name = "alertes")
public class Alerte {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "date_heure_envoi")
    private LocalDateTime dateHeureEnvoi;
    @Column
    private String contenu;
    @Column
    private Boolean lu;
    @Transient
    private List<User> users = new ArrayList<>();
    @Column
    private String type;

    public Alerte(LocalDateTime dateHeureEnvoi, String contenu, Boolean lu, String type) {
        this.dateHeureEnvoi = dateHeureEnvoi;
        this.contenu = contenu;
        this.lu = lu;
        this.type = type;
    }


   

}
