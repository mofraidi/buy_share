package com.mytfe.achat.metier;

import jdk.nashorn.internal.objects.annotations.Constructor;
import lombok.*;

import javax.persistence.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
@EqualsAndHashCode(of ={"nom"})

@Entity
@Table(name = "roles")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private Long id ;
    @Column(name = "nom")
    private String nom ;

    public Role(String nom) {
        this.nom = nom;
    }
}
