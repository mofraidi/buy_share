package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Alerte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlerteRepository extends JpaRepository<Alerte, Long> {

}
