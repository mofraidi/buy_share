package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.AdhesionRepository;
import com.mytfe.achat.dao.AnnonceRepository;
import com.mytfe.achat.dao.ArticleRespository;
import com.mytfe.achat.dao.MessageRepository;
import com.mytfe.achat.dto.AdhesionDTO;
import com.mytfe.achat.dto.AnnonceDTO;
import com.mytfe.achat.dto.ArticleDTO;
import com.mytfe.achat.dto.UserDTO;
import com.mytfe.achat.metier.*;
import com.mytfe.achat.services.GroupeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import java.util.ArrayList;
import java.util.List;



@RestController
@RequestMapping(value = "/test" , method = RequestMethod.GET )//   /groupe/membres
public class TestRepository {
    @Autowired AnnonceRepository ar;
    @Autowired AdhesionRepository adR;
    @Autowired GroupeService gs;
    @Autowired public JavaMailSender emailSender;
    @Autowired ArticleRespository arR;
    @Autowired MessageRepository mr;

    ModelMapper modelMapper = new ModelMapper();


    @RequestMapping (value = "/annonces_hql" , method = RequestMethod.GET )//   /test/annonces_hql
    public List<Annonce>  annoncesHQL(){
        Long id = Long.valueOf(4);
        return ar.annoncesLocalite(id);
    }

    @RequestMapping (value = "/annonces_hql_distance" , method = RequestMethod.GET )//   /test/annonces_hql_distance
    public List<Annonce>  annoncesHQL1(){
        //Long id = Long.valueOf(4);
        return ar.annoncesLocaliteDistance(Double.valueOf(50.8465573),Double.valueOf(4.351697),25);
    }




    /*listeAdhesioOrdered*/
    @GetMapping("/mail") //test/mail
    public void sendMail (){

        // Create a Simple MailMessage.
        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo("fraidi.mohamed@gmail.com");
        message.setSubject("Test Simple Email");
        message.setText("Hello, Im testing Simple Email");

        // Send Message!
        this.emailSender.send(message);

    }


   @GetMapping("/msg")   //test/msg
   public List<Message> allMsg(){
       List<Message> msgs = mr.findAll();
       List<Message> newMsgs = new ArrayList<>();
       for(Message message : msgs){
           message.setUsersDest(null);
           message.setUserSource(null);
           message.setGroupe(null);
           newMsgs.add(message);
       }
       return newMsgs;
   }




}//end

