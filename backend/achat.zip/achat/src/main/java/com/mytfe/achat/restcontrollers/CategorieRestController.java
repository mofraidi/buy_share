package com.mytfe.achat.restcontrollers;

import com.mytfe.achat.dao.CategorieRepository;
import com.mytfe.achat.dao.UserRepository;
import com.mytfe.achat.metier.Categorie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin

@RestController
@RequestMapping(value = "/categories" , method = RequestMethod.GET )

public class CategorieRestController {
    @Autowired
    CategorieRepository cr;
    @Autowired
    UserRepository ur;

    @RequestMapping (value = "/liste" , method = RequestMethod.GET ) //categories/liste
    public List<Categorie> listeCategorie(){
        return cr.findAll();

    }
    @GetMapping("/cat_exist") // categories/cat_exist
    public int verifiSiCategorieExist(@RequestParam String nomCat){
        Optional <Categorie> op = cr.findBynom(nomCat);
        if(op.isPresent()){return 1;}
        return 0;

    }
    @GetMapping("/enregist_cat") // categories/enregist_cat
    public int enregistrerCategorie(@RequestParam String nomCat){
        cr.save(new Categorie(nomCat));
        return 1;

    }
    @GetMapping("/modifier_cat") // categories/modifier_cat
    public int modifierCategorie(@RequestParam String nomCat, @RequestParam String nouvNomCat){
        Optional<Categorie> opC = cr.findBynom(nomCat);
        Categorie categorie = opC.get();
        categorie.setNom(nouvNomCat);
        cr.save(categorie);
        return 1;

    }
    @GetMapping("/supp_cat") // categories/supp_cat
    public int supprimerCategorie(@RequestParam String nomCat){
        Optional<Categorie> opC = cr.findBynom(nomCat);
        cr.deleteById(opC.get().getId());
        return 1;
    }




}// eof
