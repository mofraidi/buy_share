package com.mytfe.achat.objets;

import com.mytfe.achat.metier.Annonce;
import com.mytfe.achat.metier.Article;
import com.mytfe.achat.metier.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AnnonceGroupe extends Annonce {
    List<String> userNames = new ArrayList<>();

    public AnnonceGroupe(Long id, String titre, String description, LocalDateTime dateHeurePublication, int nbrMinMemmbres, int nbrMaxMembres, Article article, User userPublicateur, List<String> userNames) {
        super(id, titre, description, dateHeurePublication, nbrMinMemmbres, nbrMaxMembres, article, userPublicateur);
        this.userNames = userNames;
    }
}

