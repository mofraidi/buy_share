package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name = "journal")
public class Journal {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "date_heure")
    private LocalDateTime dateHeure;
    @Column
    private String activite ;
    @ManyToOne
    @JoinColumn(name="id_activite_journal")

    private TypeActiviteJournal typeActivJournal;







}
