package com.mytfe.achat.metier;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mytfe.achat.objets.AffichageJoursHeures;
import lombok.*;
import org.springframework.lang.Nullable;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Objects;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString @EqualsAndHashCode(of ={"user","groupe"})

@Entity
@Table(name = "adhesions")
//@IdClass(AdhesionId.class)
public class Adhesion  implements Serializable  {

    @EmbeddedId
    protected AdhesionId id;

    //@Id
    @ManyToOne
    @JoinColumn(name = "id_user", insertable = false, updatable = false)
    protected User user ;


    //@Id
    @ManyToOne
    @JoinColumn(name = "id_groupe",insertable = false, updatable = false)
    protected Groupe groupe;

    @Column (name = "approuvee")
    protected boolean approuvee;
    @Column (name = "date_heure_adh")
    @Convert(converter = LocalDateAttributeConverter.class)
    protected LocalDateTime dateHeureAdh;
    @Column (name = "date_debut_utilisation")
    @Convert(converter = LocalDateAttributeConverter.class)
    @Nullable
    //@JsonFormat(pattern = "dd-MM-yyyy HH:mm")
    //@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    protected LocalDateTime dateDebutUtilisation;
    @Column (name = "date_heure_reservation")
    @Convert(converter = LocalDateAttributeConverter.class)
    @Nullable
    @JsonFormat(pattern = "dd-MM-yyyy HH:mm")
    protected LocalDateTime dateHeureReservation;
    @Column (name = "nbr_heures_penalisation")
    protected int nbrHeuresPenalisation;
    @Column (name = "nbr_heures_utilisation")
    protected int nbrHeuresUtilisation;
    @javax.persistence.Transient
    protected AffichageJoursHeures affichageJoursHeures;

    public Adhesion(User user, Groupe groupe, boolean approuvee) {
        this.user = user;
        this.groupe = groupe;
        this.approuvee = approuvee;
    }

    public Adhesion(AdhesionId id, User user, Groupe groupe, boolean approuvee) {
        this.id = id;
        this.user = user;
        this.groupe = groupe;
        this.approuvee = approuvee;
    }

    public Adhesion(AdhesionId id, User user, Groupe groupe) {
        this.id = id;
        this.user = user;
        this.groupe = groupe;
    }
}


