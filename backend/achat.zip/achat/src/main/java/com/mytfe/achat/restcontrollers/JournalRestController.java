package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.JournalDAO;
import com.mytfe.achat.metier.Journal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/journal" , method = RequestMethod.GET )
public class JournalRestController {

    @Autowired
    JournalDAO jr;
    @GetMapping("/news") // journal/news
    public List<Journal> journal(){
        return jr.findAll();
    }

}
