package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.AdhesionRepository;
import com.mytfe.achat.dao.ArticleRespository;
import com.mytfe.achat.dao.GroupeRepository;
import com.mytfe.achat.dao.UserRepository;
import com.mytfe.achat.dto.AdhesionDTO;
import com.mytfe.achat.dto.ArticleDTO;
import com.mytfe.achat.dto.GroupeDTO;
import com.mytfe.achat.dto.UserDTO;
import com.mytfe.achat.metier.*;
import com.mytfe.achat.services.GroupeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/groupe")
public class GroupeRestController {

    @Autowired GroupeRepository gr;
    @Autowired GroupeService gs;
    @Autowired UserRepository ur;
    @Autowired AdhesionRepository adR;
    @Autowired ArticleRespository ar;
    @Autowired AdhesionRepository adhR;

    @RequestMapping (value = "/membres" , method = RequestMethod.GET )//   /groupe/membres
    public GroupeDTO membres(@RequestParam Long idGroupe){

        ModelMapper modelMapper = new ModelMapper();
        Optional op =  gr.findById(Long.valueOf(idGroupe));
        Groupe groupe ;


        if (op.isPresent()) {
            groupe = (Groupe)op.get();

            return affecterDTO(groupe);

        }
          return null;

    }



    @RequestMapping (value = "/reserver" , method = RequestMethod.GET ) //  groupe/reserver
    public GroupeDTO reserver(@RequestParam Long idUser,@RequestParam Long idGroupe){

        Optional o = ur.findById(idUser);
        User user;
        Groupe groupe;

        if(o.isPresent()) {user = (User)o.get();
            for(Adhesion ad : user.getAdhesions()){
                Groupe g = ad.getGroupe();
                if  (g.getId()==idGroupe){
                    ad.setDateHeureReservation(LocalDateTime.now().plusHours(2));
                }
            }
            ur.save(user);
        }


        Optional op = gr.findById(idGroupe);
        if(o.isPresent()){
            groupe = (Groupe)op.get();
            return affecterDTO(groupe);
        }

       return null;
    }

    @RequestMapping (value = "/passer_tour" , method = RequestMethod.GET ) //  groupe/passer_tour
    public GroupeDTO passerTour(@RequestParam Long idUser,@RequestParam Long idGroupe){

        passerTour1(idUser,idGroupe);

        Optional op = gr.findById(idGroupe);
        if(op.isPresent()){
            Groupe groupe = (Groupe)op.get();
            return affecterDTO(groupe);
        }

        return null;
    }

    @RequestMapping (value = "/mettre_dispo" , method = RequestMethod.GET ) //  groupe/mettre_dispo
    public GroupeDTO   mettreEnDisposition(@RequestParam Long idUser,@RequestParam Long idGroupe,@RequestParam int penalite,@RequestParam int delaiUtilisation,@RequestParam int delaiTransition){ System.out.println("heuresjoursPenalites converti "+gs.convertHeuresJours(penalite));

        User user;
        Groupe groupe;
        Optional op = ur.findById(idUser);
        if(op.isPresent()){
            user = (User)op.get();
            for(Adhesion ad : user.getAdhesions()){
                if(ad.getGroupe().getId()==idGroupe){

                    ad.setNbrHeuresUtilisation(delaiUtilisation);
                    if(penalite!=0){ad.setNbrHeuresPenalisation(penalite);}

                    break;
                }
            }
            ur.save(user);
        }

        passerTour1(idUser,idGroupe);
        Optional o = gr.findById(idGroupe);
        if(o.isPresent()){
            groupe = (Groupe)o.get();


            for(Adhesion adh : adR.listeAdhesioOrdered(groupe.getId())){ //// adR.listeAdhesioOrdered(groupe.getId()))
                if(adh.getDateHeureReservation()!=null){
                    adh.setDateDebutUtilisation(LocalDateTime.now().plusHours(2)); // timeZone
                    adh.setDateDebutUtilisation(adh.getDateDebutUtilisation().plusHours(delaiTransition));
                    adh.setDateHeureReservation(null);
                    break;
                }

            }

            //TODO


            gr.save(groupe);
            return affecterDTO(groupe);
        }

        return null;

    }

    public GroupeDTO affecterDTO(Groupe groupe){

        ModelMapper modelMapper = new ModelMapper();
        List<AdhesionDTO> adhesionsADH = new ArrayList<>();
        for(Adhesion ad : adR.listeAdhesioOrdered(groupe.getId())){
            AffichageAdhesion aff = new AffichageAdhesion(ad.getId(),ad.getUser(),ad.getGroupe(),ad.isApprouvee(),ad.getDateHeureAdh(),ad.getDateDebutUtilisation(),ad.getDateHeureReservation(),ad.getNbrHeuresPenalisation(),ad.getNbrHeuresUtilisation(),ad.getAffichageJoursHeures());
            //aff = (AffichageAdhesion) ad;

            aff.setDelaiUtilisationJH(gs.convertHeuresJours(ad.getNbrHeuresUtilisation()));
            aff.setNbrHeuresPenalisationJH(gs.convertHeuresJours(ad.getNbrHeuresPenalisation()));

            //ad.setAffichageJoursHeures(gs.convertHeuresJours(ad.getNbrHeuresUtilisation()));
            AdhesionDTO adDTO = modelMapper.map(aff, AdhesionDTO.class);
            UserDTO userDTO = modelMapper.map(ad.getUser(), UserDTO.class);

            adDTO.setUserDTO(userDTO);
            //adDTO.setAffichageJoursHeures(gs.convertHeuresJours(ad.getNbrHeuresUtilisation()));
            adhesionsADH.add(adDTO);
        }
        GroupeDTO groupeDTO = modelMapper.map(groupe, GroupeDTO.class);
        ArticleDTO articleDTO = modelMapper.map(groupe.getArticle(), ArticleDTO.class);
        groupeDTO.setArticle(articleDTO);
        groupeDTO.setAdhesions(adhesionsADH);
        return groupeDTO;


    }









    public void passerTour1(Long idUser,Long idGroupe){

        Optional o = ur.findById(idUser);
        User user;
        Groupe groupe;

        if(o.isPresent()) {user = (User)o.get();
            for(Adhesion ad : user.getAdhesions()){
                Groupe g = ad.getGroupe();
                if  (g.getId()==idGroupe){
                    ad.setDateHeureReservation(null);
                    ad.setDateDebutUtilisation(null);
                }
            }
            ur.save(user);
        }


    }
    @RequestMapping (value = "/mes_groupes" , method = RequestMethod.GET ) //  groupe/mes_groupes
    public List<GroupeDTO> mesGroupes(@RequestParam Long idUser){
        List<GroupeDTO> mesGroupesDTO = new ArrayList();
        List<Groupe> mesGroupes =  gr.findGroupesByUser(idUser);
        for(Groupe groupe : mesGroupes){
            GroupeDTO gDTO = affecterDTO(groupe);
            mesGroupesDTO.add(gDTO);
        }
        return mesGroupesDTO;
    }

    @GetMapping("/joindre_groupe") // groupe/joindre_groupe
    public int demadeJoindreGroupe(@RequestParam Long idUser,@RequestParam Long idArticle) {


        Optional<User>opU = ur.findById(idUser);
        Optional<Article> opA = ar.findById(idArticle);
        Optional<Groupe> opG = gr.findById(gr.findGroupeByIdArticle(idArticle));

        AdhesionId adhesionId = new AdhesionId(opU.get().getId(),opG.get().getId() );
        Adhesion ad = new Adhesion(adhesionId,opU.get(),opG.get(),false);
        adhR.save(ad);
        Groupe groupe = opG.get();
        groupe.getMembres().add(ad);
        gr.save(groupe);

        User user = opU.get();
        String contenu = "nouvelle demande de validation pour le groupe: "+groupe.getId()+" avec l'article : "+groupe.getArticle().getNom();
        String type = "demande de validation";
        Alerte alerte = new Alerte(LocalDateTime.now(),contenu,false,type);
        user.getAlertes().add(alerte);
        ur.save(user);

        return 1;
    }

    @GetMapping("/rejeter") //groupe/valider
    public int rejeterJoindreGroupe(@RequestParam Long idUser,@RequestParam Long idGroupe){
        Optional<User>opU = ur.findById(idUser);
        Optional<Groupe>opG = gr.findById(idGroupe);
        Adhesion adhesion = adhR.findByUserAndGroupe(opU.get(),opG.get());
        adhR.delete(adhesion);
        return 1;


    }

    @GetMapping("/valider") //groupe/valider
    public int validerJoindreGroupe(@RequestParam Long idUser,@RequestParam Long idGroupe){


        Optional<User>opU = ur.findById(idUser);
        Optional<Groupe>opG = gr.findById(idGroupe);
        Adhesion adhesion = adhR.findByUserAndGroupe(opU.get(),opG.get());
        adhesion.setApprouvee(true);
        adhesion.setNbrHeuresPenalisation(0);
        adhesion.setNbrHeuresUtilisation(opG.get().getArticle().getDelaiUtilisation());
        adhesion.setDateHeureAdh(LocalDateTime.now());
        adhR.save(adhesion);

        String contenu = "la demande pour joindre le groupe : "+opG.get().getId()+" avec l'article : "+opG.get().getArticle().getNom()+"est validée";
        String type = "demande de joindre le groupe validée";
        Alerte alerte = new Alerte(LocalDateTime.now(),contenu,false,type);
        User user = opU.get();
        user.getAlertes().add(alerte);
        ur.save(user);


        return 1;

    }

    @GetMapping("/user_names") //groupe/user_names
    public List<String> membresUserNamesMonGroupe(@RequestParam Long idUser, @RequestParam Long idGroupe){
       return  gr.findUserNamesDeMonGroupe(idUser, idGroupe);

    }
    @GetMapping("/config_groupe") // groupe/config_groupe
    public int configueGroupe(@RequestParam Long idGroupe,@RequestParam  int delaiUtilisation,@RequestParam  int delaiMinUtilisation,@RequestParam  int delaiTransition){

        Optional <Groupe> opG = gr.findById(idGroupe);
        Optional<Article> opA = ar.findById(opG.get().getArticle().getId());
        Article article = opA.get();
        article.setDelaiUtilisation(delaiUtilisation);
        article.setDelaiMinUtilisation(delaiMinUtilisation);
        article.setDelaiTransition(delaiTransition);
        ar.save(article);
         return 1;

    }

}//eof
