package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Data @AllArgsConstructor @NoArgsConstructor @ToString

@Entity (name = "localites")
public class Localite implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "code_postal")
    private String codePstal;
    @Column
    private String nom;
    @Column
    private Double longitude;
    @Column
    private Double latitude;
}
