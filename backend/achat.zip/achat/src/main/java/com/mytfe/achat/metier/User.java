package com.mytfe.achat.metier;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString @EqualsAndHashCode(of ={"userName"})

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column (name = "user_name")
    private String userName;
    @Column(name = "mot_de_passe")
    private String passWord;
    @Column
    private String email;
    @Column
    private boolean confirmation;
    @Column (name = "date_heure_inscription") @Convert(converter = LocalDateAttributeConverter.class) @JsonFormat(pattern = "dd/MM/yyyy HH:mm")
    private LocalDateTime dateHeureInscription ;
    @Column (name = "date_derniere_connexion") @Convert(converter = LocalDateAttributeConverter.class) @JsonFormat(pattern = "dd/MM/yyyy HH:mm")
    private LocalDateTime dateDerniereConnexion ;
    @Column(name="code_confirmation")
    private String codeConfirmation;
    @ManyToOne
    @JoinColumn(name="id_role")
    private Role role;
    @ManyToOne
    @JoinColumn(name="id_localite")
    private Localite localite;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "id_blocage")
    private Blocage blocage;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    @OrderBy("dateHeureReservation ASC")
    private List<Adhesion> adhesions = new ArrayList<>();
    @OneToMany(mappedBy ="userPublicateur")
    private List<Annonce> annonces = new ArrayList<>();

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "alertes_users",
            joinColumns = @JoinColumn(name = "id_user"),
            inverseJoinColumns = @JoinColumn(name = "id_alerte"))
    @OrderBy("dateHeureEnvoi DESC")
    private List<Alerte> alertes = new ArrayList<>();

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "messages_users",
            joinColumns = @JoinColumn(name = "id_user_dest"),
            inverseJoinColumns = @JoinColumn(name = "id_message"))
    private List<Message> messages = new ArrayList<>();

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "users_signale_comments",
            joinColumns = @JoinColumn(name = "id_user"),
            inverseJoinColumns = @JoinColumn(name = "id_comment"))

    private List<Commentaire> commentaires = new ArrayList<>();

    public User(String userName, String passWord, String email) {
        this.userName = userName;
        this.passWord = passWord;
        this.email = email;
    }
}
