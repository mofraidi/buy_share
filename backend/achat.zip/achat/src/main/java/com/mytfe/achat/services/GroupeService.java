package com.mytfe.achat.services;

import com.mytfe.achat.objets.AffichageJoursHeures;
import org.springframework.stereotype.Service;

@Service
public class GroupeService {

    public AffichageJoursHeures convertHeuresJours(int nbrHeures){

        if(nbrHeures<24) return new AffichageJoursHeures(0,nbrHeures);

        int jours = nbrHeures/24;
        int heures = nbrHeures - (jours * 24);
        return new AffichageJoursHeures(jours,heures);
    }
}
