package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Journal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JournalDAO extends JpaRepository<Journal, Long> {
}
