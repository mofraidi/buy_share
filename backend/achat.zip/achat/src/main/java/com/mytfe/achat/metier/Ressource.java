package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name = "ressources")
public class Ressource {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    @Column
    String lien;
    @ManyToOne
    @JoinColumn(name="id_article")
    Article article;

    public Ressource(String lien) {
        this.lien = lien;
    }

    public Ressource(String lien, Article article) {
        this.lien = lien;
        this.article = article;
    }
}
