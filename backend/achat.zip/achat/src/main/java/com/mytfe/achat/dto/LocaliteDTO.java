package com.mytfe.achat.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
public class LocaliteDTO {

    private Long id;
    private String codePstal;
    private String nom;


}
