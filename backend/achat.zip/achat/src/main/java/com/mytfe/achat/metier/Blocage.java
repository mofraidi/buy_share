package com.mytfe.achat.metier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity(name = "blocages")
public class Blocage implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    @Column
    boolean bloque;
    @Column(name = "date_heure_debut")
    LocalDateTime dateHeureDebut;
    @Column @Nullable
    int duree;

    public Blocage(boolean bloque, LocalDateTime dateHeureDebut, int duree) {
        this.bloque = bloque;
        this.dateHeureDebut = dateHeureDebut;
        this.duree = duree;
    }
}
