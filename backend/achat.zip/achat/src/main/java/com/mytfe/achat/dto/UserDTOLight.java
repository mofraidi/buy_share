package com.mytfe.achat.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(of ={"id"})
public class UserDTOLight {
    Long id;
    String UserName;
}
