package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Localite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface LocaliteRepository extends JpaRepository<Localite, Long> {

    @Query(value = "select * from localites where code_postal = ? limit 1", nativeQuery = true)
    Optional<Localite> findByCodePstal(String codePostal);
    Optional<Localite>findBynom(String nom);

}
