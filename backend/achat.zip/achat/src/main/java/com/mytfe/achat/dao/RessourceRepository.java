package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Ressource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RessourceRepository extends JpaRepository<Ressource, Long> {
    Optional<Ressource> findBylien(String lien);
}
