package com.mytfe.achat.restcontrollers;


import com.mytfe.achat.dao.*;
import com.mytfe.achat.dto.*;
import com.mytfe.achat.interfaces.DtoUtil;
import com.mytfe.achat.metier.*;
import com.mytfe.achat.objets.AnnonceGroupe;
import com.mytfe.achat.services.FileService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping(value = "/annonces" , method = RequestMethod.GET )
public class AnnonceRestController implements DtoUtil<AnnonceDTO,Annonce> {
    @Autowired AnnonceRepository ar;
    @Autowired LocaliteRepository lr;
    @Autowired CategorieRepository cr;
    @Autowired FileService fileService;
    @Autowired ArticleRespository arR;
    @Autowired UserRepository ur;
    @Autowired RessourceRepository rr;
    @Autowired GroupeRepository gr;
    @Autowired AdhesionRepository adhR;

    ModelMapper modelMapper = new ModelMapper();

    @RequestMapping (value = "/liste_annonces" , method = RequestMethod.GET )//   /annonces/liste_annonces
    public List<AnnonceDTO> listeAnnonces(){
        List<AnnonceDTO> listeAnnoncesDTO= new ArrayList<>();
        List <Annonce> listeAnnonces= ar.findAll();
        for(Annonce ann : listeAnnonces ){
            AnnonceDTO annDTO = affecterDAO(ann);
            listeAnnoncesDTO.add(annDTO);
        }

        return listeAnnoncesDTO;
    }



    @RequestMapping (value = "/liste_annonces_filtres" , method = RequestMethod.GET )//   /annonces/liste_annonces_filtres
    public List<AnnonceDTO>   listeAnnoncesFiltres(String motCle,String cat, String codePostal, int distance){
        Double longitude = null;
        Double latitude = null;
        String nomLocalite = null;
        motCle=(motCle.equals(""))?null:motCle;
        cat=(cat.equals(""))?null:cat;
        if(codePostal.equals("")){codePostal="1000";} // si pas de code postal,recherche à bruxelles
        if(distance == 0){distance = 500;}// si pas de distance recherche dans un périmetre de 500km


        List<AnnonceDTO> listeAnnoncesDTO= new ArrayList<>();
        Optional<Localite> op = lr.findByCodePstal(codePostal);
        if(op.isPresent()){
            Localite loc = op.get();
            longitude = loc.getLongitude();
            latitude = loc.getLatitude();
            nomLocalite = loc.getNom();
        }

        List <Annonce> listeAnnonces= ar.annoncesLocaliteDistanceFiltre(latitude,longitude,distance,motCle,cat);
        for(Annonce ann : listeAnnonces ){
            AnnonceDTO annDTO = affecterDAO(ann);
            listeAnnoncesDTO.add(annDTO);
        }
         System.out.println("mot cle : "+motCle+" cat : "+cat+" codePostal : "+codePostal+"longitude : "+longitude+" latitude : "+latitude+" nomLocalite : "+nomLocalite+"categorie :"+cat);
        System.out.println("motcle = null : "+(motCle==null)+"cat = "+(cat==null));
        return listeAnnoncesDTO;
    }

    @GetMapping("/liste_categories")// /annonces/liste_categories
    public List<Categorie> listeCategories(){
        return cr.findAll();

    }

    @PostMapping(value = "/files" ,consumes="multipart/form-data", produces="application/json")  ///annonces/files
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public  int PublierAnnonce (@RequestParam ("files[]") MultipartFile[] files,
                                   @RequestParam ("titre")String titre,
                                   @RequestParam ("description")String description,
                                   @RequestParam ("nbrMin")String nbrMin,
                                   @RequestParam ("nbrMax")String nbrMax,
                                   @RequestParam ("nomArticle")String nomArticle,
                                   @RequestParam ("prix")String prix,
                                   @RequestParam ("categorie")String cat,
                                   @RequestParam ("delaiUtilisation")String delaiUtilisation,
                                   @RequestParam ("delaiMinUtilisation")String delaiMinUtilisation,
                                   @RequestParam ("delaiTransition")String delaiTransition,
                                   @RequestParam ("userName")String userName
                                    ) throws IOException { // @RequestBody Map<file,MultipartFile[]>


        System.out.println(" titre = "+titre+" description = "+description+" nbrMin = "+nbrMin+" nbrMax = "+nbrMax+" nomArticle = "+nomArticle+" prix = "+prix+" categorie = "+cat+" delaiUtilisation = "+delaiUtilisation+" delaiMinUtilisation = "+delaiMinUtilisation+" delaiTransition = "+delaiTransition);
        Double prixA = Double.valueOf(prix);
        int delUtil = Integer.parseInt(delaiUtilisation);
        int delMinUtil = Integer.parseInt(delaiMinUtilisation);
        int delTrans = Integer.parseInt(delaiTransition);

        Optional <Categorie> opC = cr.findBynom(cat);
        Optional<User> opU = ur.findByuserName(userName);
        Article article = new Article(nomArticle,description,prixA,delUtil,delMinUtil,delTrans,opC.get());
        arR.save(article);
        Annonce annonce = new Annonce(titre,description, LocalDateTime.now(),Integer.parseInt(nbrMin),Integer.parseInt(nbrMax),article,opU.get());
        ar.save(annonce);

        Groupe groupe = new Groupe(false, article, opU.get(),null);
        gr.save(groupe);
        AdhesionId adhId = new AdhesionId(opU.get().getId(),groupe.getId());
        Adhesion adhesion = new Adhesion(adhId,opU.get(),gr.save(groupe),true);
        adhesion.setDateHeureAdh(LocalDateTime.now());
        adhR.save(adhesion);
        List<Adhesion> adhs = new ArrayList<>();
        adhs.add(adhesion);

        groupe.setMembres(adhs);
        gr.save(groupe);

        for(MultipartFile uploadedFile : files) {
            String nouveauNom = fileService.storeFile(uploadedFile, userName);
            Ressource ressource = new Ressource(nouveauNom,article);
            rr.save(ressource);

        }

        return 1;

    }

    @PostMapping(value = "/modif_annonce" ,consumes="multipart/form-data", produces="application/json")  ///annonces/modif_annonce
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public  int  /*handleFileUpload*/ModifierAnnonce(@RequestParam ("files[]") MultipartFile[] files,
                                                      @RequestParam ("idAnnonce")Long idAnnonce,
                                                      @RequestParam ("idArticle")Long idArticle,
                                                      @RequestParam ("titre")String titre,
                                                     @RequestParam ("description")String description,
                                                     @RequestParam ("nbrMin")String nbrMin,
                                                     @RequestParam ("nbrMax")String nbrMax,
                                                     @RequestParam ("nomArticle")String nomArticle,
                                                     @RequestParam ("prix")String prix,
                                                     @RequestParam ("categorie")String cat,
                                                     @RequestParam ("delaiUtilisation")String delaiUtilisation,
                                                     @RequestParam ("delaiMinUtilisation")String delaiMinUtilisation,
                                                     @RequestParam ("delaiTransition")String delaiTransition,
                                                     @RequestParam ("userName")String userName
    ) throws IOException { // @RequestBody Map<file,MultipartFile[]>


        System.out.println(" titre = "+titre+" description = "+description+" nbrMin = "+nbrMin+" nbrMax = "+nbrMax+" nomArticle = "+nomArticle+" prix = "+prix+" categorie = "+cat+" delaiUtilisation = "+delaiUtilisation+" delaiMinUtilisation = "+delaiMinUtilisation+" delaiTransition = "+delaiTransition+" length = "+files.length);
        Double prixA = Double.valueOf(prix);
        int delUtil = Integer.parseInt(delaiUtilisation);
        int delMinUtil = Integer.parseInt(delaiMinUtilisation);
        int delTrans = Integer.parseInt(delaiTransition);

        Optional <Categorie> opC = cr.findBynom(cat);
        Optional<User> opU = ur.findByuserName(userName);
        Optional<Article> opA = arR.findById(idArticle);
        Article article1 = opA.get();
        article1.setNom(nomArticle);
        article1.setDescription(description);
        article1.setPrix(prixA);
        article1.setDelaiUtilisation(delUtil);
        article1.setDelaiMinUtilisation(delMinUtil);
        article1.setDelaiTransition(delTrans);
        article1.setCategorie(opC.get());
        if(files.length!=0){

            List<Ressource> ressources = article1.getRessources();

            for(Ressource res : ressources){
                fileService.deleteRessource(res.getLien()); // todo
            }

             for(Ressource ressource : article1.getRessources()){
                 System.out.println("lien a supprimer : "+ressource.getLien());
                 Optional<Ressource> opR = rr.findBylien(ressource.getLien());
                 //System.out.println(ressource);
                 if(opR.isPresent()){
                     System.out.println("ressource presente !");
                     rr.delete(opR.get());
                     System.out.println("ressource supprimée !");

                 }


             }

            System.out.println("size of ressources before clear = "+article1.getRessources().size());
        article1.getRessources().clear();
            System.out.println("size of ressources after clear = "+article1.getRessources().size());

        }

        arR.save(article1);
        //Article article = new Article(nomArticle,description,prixA,delUtil,delMinUtil,delTrans,opC.get());
        //arR.save(article);
        Optional<Annonce> opAn = ar.findById(idAnnonce);
        Annonce annonce1 = opAn.get();
        annonce1.setTitre(titre);
        annonce1.setDescription(description);
        annonce1.setNbrMaxMembres(Integer.parseInt(nbrMax));
        annonce1.setNbrMinMemmbres(Integer.parseInt(nbrMin));
        annonce1.setArticle(article1);
        ar.save(annonce1);
        //Annonce annonce = new Annonce(titre,description, LocalDateTime.now(),Integer.parseInt(nbrMin),Integer.parseInt(nbrMax),article,opU.get());
        //ar.save(annonce);
         Optional<Groupe> opG = gr.findByIDArticle(idArticle);
        Groupe groupe1 = opG.get();
        groupe1.setArticle(article1);
        gr.save(groupe1);
        //Groupe groupe = new Groupe(false, article, opU.get(),null);// todo
        //gr.save(groupe);
        AdhesionId adhId = new AdhesionId(opU.get().getId(),groupe1.getId());
        Adhesion adhesion = new Adhesion(adhId,opU.get(),gr.save(groupe1),true);
        adhesion.setDateHeureAdh(LocalDateTime.now());
        adhR.save(adhesion);
        List<Adhesion> adhs = new ArrayList<>();
        adhs.add(adhesion);

        groupe1.setMembres(adhs);
        gr.save(groupe1);

        for(MultipartFile uploadedFile : files) {
            String nouveauNom = fileService.storeFile(uploadedFile, userName);
            Ressource ressource = new Ressource(nouveauNom,article1);
            rr.save(ressource);

        }

      return 1;

    }
    @GetMapping("/req_test")
    public boolean testReq (@RequestParam String lien){
        Optional<Ressource> opR = rr.findBylien(lien);
        return (opR.isPresent());
    }

    @GetMapping("/mes_annonces") //annonces/mes_annonces
    public List<AnnonceDTO> mesAnnonces(@RequestParam Long idUser){
        List<AnnonceDTO> annoncesDTO = new ArrayList();
       for(Annonce annonce : ar.findByIDPublicateur(idUser)){
           annoncesDTO.add(affecterDAO(annonce));
       }
       return annoncesDTO;
    }

    public AnnonceDTO affecterDAO(Annonce annonce){
       List<RessourceDTO> ressourcesDTO = new ArrayList<>();
       for(Ressource rd: annonce.getArticle().getRessources()){
           rd.setArticle(null);
           ressourcesDTO.add(modelMapper.map(rd,RessourceDTO.class));
       }

        UserDTO userDTO = modelMapper.map(annonce.getUserPublicateur(),UserDTO.class);
       //userDTO.setAdhesions(null);
        userDTO.setRole(null);
        ArticleDTO articleDTO = modelMapper.map(annonce.getArticle(),ArticleDTO.class);
        articleDTO.setRessourcesDTO(ressourcesDTO);
        AnnonceDTO annonceDTO = modelMapper.map(annonce,AnnonceDTO.class);
        annonceDTO.setUserPublicateurDTO(userDTO);
        annonceDTO.setArticleDTO(articleDTO);
        return annonceDTO;



    }

    @GetMapping("/liste_membres_annonce")
    public List<String> listeMembresAnnonce(@RequestParam Long idArticle){
        Long id_groupe = gr.findGroupeByIdArticle(idArticle);

        System.out.println("id_groupe = "+id_groupe+"idArticle"+idArticle);
        List<String> userNames = gr.findUserNamesByIdGroupe(id_groupe);
        return userNames;
    }

    @GetMapping("/alertes")
    public List<Alerte> alerteUser(@RequestParam Long idUser){
        Optional<User> opU = ur.findById(Long.valueOf(26));
        return opU.get().getAlertes();
    }


   @GetMapping("/finaliser")  ///annonces/finaliser
    public int finaliserAnnonce(@RequestParam Long idAnnonce){
        Optional<Annonce> opA = ar.findById(idAnnonce);
        Optional<Groupe> opG = gr.findByIDArticle(opA.get().getArticle().getId());
        Annonce annonce = opA.get();
        Groupe groupe = opG.get();
        groupe.setEtat(true);
        gr.save(groupe);
       Alerte alerte = new Alerte(LocalDateTime.now(),"l'annonce avec article : "+opA.get().getArticle().getNom()+" a été finalisée",false,"Annonce finalisé");
       for(Adhesion adh : groupe.getMembres()){
           User user = adh.getUser();
           user.getAlertes().add(alerte);
           ur.save(user);
           adh.setDateHeureReservation(adh.getDateHeureAdh());
           adhR.save(adh);

       }
        ar.delete(annonce);

        return 1;
   }

   @GetMapping("/annonce")
   public AnnonceDTO getAnnonce(@RequestParam Long idAnnonce){
        Optional<Annonce> opA = ar.findById(idAnnonce);
        AnnonceDTO annonceDTO = affecterDAO(opA.get());
        return annonceDTO;
   }

}
