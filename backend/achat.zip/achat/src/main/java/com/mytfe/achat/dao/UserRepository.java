package com.mytfe.achat.dao;

import com.mytfe.achat.dto.AdhesionDTO;
import com.mytfe.achat.metier.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    public Optional<User> findByuserName(String userName);

    @Procedure(procedureName = "select_membres_groupe")
    List<User> membreGroupes(@Param("id_groupe_in") int idGroupe);



    @Query(value = "from User u where u.id = ?1")
    User userid(Long id);



    @Query(value = "from User u ")
    List<User> allUsers();

   Optional<User> findByUserNameAndPassWord (String username,String password);

   Optional<User> findByemail(String eMail);



}
