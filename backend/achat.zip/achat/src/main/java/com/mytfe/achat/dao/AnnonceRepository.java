package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Annonce;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.Nullable;

import java.util.List;

public interface AnnonceRepository extends JpaRepository<Annonce,Long> {

    @Query(value = "from Annonce an inner join fetch an.userPublicateur where an.userPublicateur.localite.id = :id")
    List<Annonce> annoncesLocalite(@Param("id") Long id);




    @Query(value = "select  a.* ,  SQRT ( POW(69.1 * (loc.latitude - ?), 2) + POW(69.1 * (? - loc.longitude) * COS(loc.latitude / 57.3), 2)) AS distance\n" +
            "from annonces a, localites loc, users u\n" +
            "where a.id_user_publicateur = u.id\n" +
            "and loc.id = u.id_localite\n" +
            "HAVING distance < ? ORDER BY distance", nativeQuery = true)
    List<Annonce> annoncesLocaliteDistance(Double myLatitude,Double myLongitude,int distance);


    @Query(value = "select  a.* ,  SQRT ( POW(69.1 * (loc.latitude - :myLatitude), 2) + POW(69.1 * (:myLongitude - loc.longitude) * COS(loc.latitude / 57.3), 2)) AS distance\n" +
            "from annonces a, localites loc, users u, categories ca, articles ar\n" +
            "where a.id_user_publicateur = u.id\n" +
            "and loc.id = u.id_localite\n" +
            "and ar.id_categorie = ca.id\n" +
            "and a.id_article = ar.id\n"+
            "and (a.description like  Concat('%',:motCle,'%') or :motCle is null )\n"+
            "and (ca.nom = :cat or :cat is null )"+
            "HAVING distance < :distance ORDER BY distance", nativeQuery = true)
    List<Annonce> annoncesLocaliteDistanceFiltre(@Param(value = "myLatitude") Double myLatitude, @Param(value = "myLongitude")Double myLongitude, @Param(value = "distance")int distance, @Param(value = "motCle")String motCle, @Param(value = "cat") String cat);


    @Query(value = "from Annonce an inner join fetch an.userPublicateur where an.userPublicateur.id = :idPublicateur")
    List<Annonce> findByIDPublicateur(@Param(value = "idPublicateur")Long idPublicateur);



}
