package com.mytfe.achat.dao;

import com.mytfe.achat.metier.Groupe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface GroupeRepository extends JpaRepository<Groupe, Long> {

    @Query(value = "select g.* from groupes g, adhesions a where g.id = a.id_groupe and a.id_user = :id", nativeQuery = true)
    List<Groupe> findGroupesByUser(@Param (value ="id")Long id);

    @Query(value = "select id from groupes where id_article =:id_art", nativeQuery = true)
    Long findGroupeByIdArticle(@Param (value ="id_art")Long id);


    @Query(value = "SELECT user_name FROM users as u, adhesions as adh\n where u.id = adh.id_user and id_groupe=:id_grp", nativeQuery = true)
    List<String> findUserNamesByIdGroupe(@Param (value ="id_grp")Long id);

    @Query(value = "select user_name from users as u, groupes as g, adhesions as a where u.id = a.id_user and g.id = a.id_groupe and a.id_user <>:id_usr and a.id_groupe =:id_grp", nativeQuery = true)
    List<String> findUserNamesDeMonGroupe(@Param (value ="id_usr")Long id_usr, @Param (value ="id_grp")Long id_grp);

    @Query(value = "from Groupe gr inner join fetch gr.article where gr.article.id = :idArticle")
    Optional <Groupe> findByIDArticle(@Param(value = "idArticle")Long idArticle);






}

